package com.khierkian.scanner;

import com.khierkian.dao.ActivityLogDAO;
import com.khierkian.dao.InventoryDAO;
import com.khierkian.dao.UserDAO;
import com.khierkian.model.AirConditioningUnit;
import com.khierkian.model.Material;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpsConfigurator;
import com.sun.net.httpserver.HttpsServer;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.sql.SQLException;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A small local-network web server so a phone browser can scan a barcode/QR
 * code and update inventory directly — no separate mobile app to install.
 * Only reachable on the same WiFi network (nothing is exposed to the internet).
 *
 * Runs over HTTPS with a self-signed certificate — phone browsers refuse
 * camera access entirely over plain HTTP on anything other than "localhost",
 * so HTTPS is required even for a purely local tool like this one. The
 * certificate isn't from a trusted authority, so the phone will show a
 * one-time "connection isn't private" warning the first time it connects —
 * that's expected; tap through it once (see README).
 */
public class ScannerServer {

    private static final String KEYSTORE_RESOURCE = "scanner-keystore.jks";
    private static final String KEYSTORE_PASSWORD = "khierkian1234";

    private final UserDAO userDAO = new UserDAO();
    private final InventoryDAO inventoryDao = new InventoryDAO();
    private final ActivityLogDAO activityLog = new ActivityLogDAO();

    /** token -> username. Cleared when the server stops; tokens don't need to survive a restart. */
    private final Map<String, String> sessions = new ConcurrentHashMap<>();

    private HttpServer server;
    private int port = -1;

    public boolean isRunning() {
        return server != null;
    }

    public int getPort() {
        return port;
    }

    /**
     * Finds the IP address other devices on your WiFi would use to reach this
     * computer. InetAddress.getLocalHost() is unreliable for this on Windows —
     * it can return a VPN/virtual-adapter address instead of your real WiFi IP.
     * Opening a UDP "connection" to a public address (no packets are actually
     * sent) makes the OS report which local interface it would route through,
     * which is what we actually want here.
     */
    public String getLocalIp() {
        try (java.net.DatagramSocket socket = new java.net.DatagramSocket()) {
            socket.connect(InetAddress.getByName("8.8.8.8"), 10002);
            return socket.getLocalAddress().getHostAddress();
        } catch (Exception e) {
            try {
                return InetAddress.getLocalHost().getHostAddress();
            } catch (IOException ex) {
                return "unknown";
            }
        }
    }

    public void start(int preferredPort) throws Exception {
        if (server != null) return;

        SSLContext sslContext = buildSslContext();
        HttpsServer httpsServer = HttpsServer.create(new InetSocketAddress(preferredPort), 0);
        httpsServer.setHttpsConfigurator(new HttpsConfigurator(sslContext));
        server = httpsServer;
        this.port = preferredPort;

        server.createContext("/", this::handleIndex);
        server.createContext("/api/login", this::handleLogin);
        server.createContext("/api/scan", this::handleScan);
        server.createContext("/api/adjust", this::handleAdjust);
        server.createContext("/api/register", this::handleRegister);

        server.setExecutor(Executors.newFixedThreadPool(4));
        server.start();
    }

    private SSLContext buildSslContext() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("JKS");
        try (InputStream in = ScannerServer.class.getClassLoader().getResourceAsStream(KEYSTORE_RESOURCE)) {
            if (in == null) {
                throw new IllegalStateException(
                        KEYSTORE_RESOURCE + " not found on classpath. Generate it first — see README \"Scanner HTTPS setup\".");
            }
            keyStore.load(in, KEYSTORE_PASSWORD.toCharArray());
        }

        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(keyStore, KEYSTORE_PASSWORD.toCharArray());

        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(keyStore);

        SSLContext context = SSLContext.getInstance("TLS");
        context.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);
        return context;
    }

    public void stop() {
        if (server != null) {
            server.stop(0);
            server = null;
            port = -1;
            sessions.clear();
        }
    }

    // ================= handlers =================

    private void handleIndex(HttpExchange ex) throws IOException {
        respondHtml(ex, 200, PAGE_HTML);
    }

    private void handleLogin(HttpExchange ex) throws IOException {
        if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
            respondJson(ex, 405, "{\"ok\":false,\"message\":\"Method not allowed\"}");
            return;
        }
        Map<String, String> body = readJsonBody(ex);
        String username = body.getOrDefault("username", "");
        String password = body.getOrDefault("password", "");

        try {
            UserDAO.AuthResult result = userDAO.authenticate(username, password);
            if (result.status != UserDAO.AuthStatus.SUCCESS) {
                respondJson(ex, 200, "{\"ok\":false,\"message\":\"Invalid username or password.\"}");
                return;
            }
            if (!"Technical Staff".equalsIgnoreCase(result.user.getRole())) {
                respondJson(ex, 200, "{\"ok\":false,\"message\":\"Only Technical Staff accounts can scan.\"}");
                return;
            }
            String token = UUID.randomUUID().toString();
            sessions.put(token, username);
            respondJson(ex, 200, "{\"ok\":true,\"token\":\"" + token + "\",\"name\":\"" + jsonEscape(result.user.getFirstName()) + "\"}");
        } catch (SQLException e) {
            respondJson(ex, 200, "{\"ok\":false,\"message\":\"Database error. Try again.\"}");
        }
    }

    private void handleScan(HttpExchange ex) throws IOException {
        if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
            respondJson(ex, 405, "{\"ok\":false,\"message\":\"Method not allowed\"}");
            return;
        }
        Map<String, String> body = readJsonBody(ex);
        String token = body.getOrDefault("token", "");
        String code = body.getOrDefault("code", "").trim();

        if (!sessions.containsKey(token)) {
            respondJson(ex, 200, "{\"ok\":false,\"message\":\"Session expired. Please log in again.\"}");
            return;
        }
        if (code.isEmpty()) {
            respondJson(ex, 200, "{\"ok\":false,\"message\":\"Empty code.\"}");
            return;
        }

        try {
            Optional<AirConditioningUnit> unit = inventoryDao.findUnitBySerial(code);
            if (unit.isPresent()) {
                AirConditioningUnit u = unit.get();
                respondJson(ex, 200, "{\"ok\":true,\"itemType\":\"AC\",\"id\":" + u.getId()
                        + ",\"name\":\"" + jsonEscape(u.getBrand() + " " + u.getModelNo()) + "\""
                        + ",\"quantity\":" + u.getQuantity() + ",\"status\":\"" + jsonEscape(u.getStatus()) + "\"}");
                return;
            }
            Optional<Material> material = inventoryDao.findMaterialByBarcode(code);
            if (material.isPresent()) {
                Material m = material.get();
                respondJson(ex, 200, "{\"ok\":true,\"itemType\":\"MATERIAL\",\"id\":" + m.getId()
                        + ",\"name\":\"" + jsonEscape(m.getName()) + "\""
                        + ",\"quantity\":" + m.getQuantity() + ",\"status\":\"\"}");
                return;
            }
            respondJson(ex, 200, "{\"ok\":false,\"notFound\":true,\"code\":\"" + jsonEscape(code)
                    + "\",\"message\":\"No AC unit or material matches this code.\"}");
        } catch (SQLException e) {
            respondJson(ex, 200, "{\"ok\":false,\"message\":\"Database error looking up that code.\"}");
        }
    }

    /** Auto-creates a new AC unit when a scanned code matched nothing - see InventoryDAO.registerNewUnitFromScan. */
    private void handleRegister(HttpExchange ex) throws IOException {
        if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
            respondJson(ex, 405, "{\"ok\":false,\"message\":\"Method not allowed\"}");
            return;
        }
        Map<String, String> body = readJsonBody(ex);
        String token = body.getOrDefault("token", "");
        String code = body.getOrDefault("code", "").trim();

        String username = sessions.get(token);
        if (username == null) {
            respondJson(ex, 200, "{\"ok\":false,\"message\":\"Session expired. Please log in again.\"}");
            return;
        }
        if (code.isEmpty()) {
            respondJson(ex, 200, "{\"ok\":false,\"message\":\"Empty code.\"}");
            return;
        }

        try {
            AirConditioningUnit u = inventoryDao.registerNewUnitFromScan(code);
            activityLog.log(username, "SCAN_REGISTER", "Auto-registered new AC unit from scan (serial " + code + ") - needs full details");
            respondJson(ex, 200, "{\"ok\":true,\"itemType\":\"AC\",\"id\":" + u.getId()
                    + ",\"name\":\"" + jsonEscape(u.getBrand() + " " + u.getModelNo()) + "\""
                    + ",\"quantity\":" + u.getQuantity() + ",\"status\":\"" + jsonEscape(u.getStatus()) + "\"}");
        } catch (SQLException e) {
            respondJson(ex, 200, "{\"ok\":false,\"message\":\"Database error registering that unit.\"}");
        }
    }

    private void handleAdjust(HttpExchange ex) throws IOException {
        if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
            respondJson(ex, 405, "{\"ok\":false,\"message\":\"Method not allowed\"}");
            return;
        }
        Map<String, String> body = readJsonBody(ex);
        String token = body.getOrDefault("token", "");
        String itemType = body.getOrDefault("itemType", "");
        String idStr = body.getOrDefault("id", "");
        String deltaStr = body.getOrDefault("delta", "0");

        String username = sessions.get(token);
        if (username == null) {
            respondJson(ex, 200, "{\"ok\":false,\"message\":\"Session expired. Please log in again.\"}");
            return;
        }

        int id;
        int delta;
        try {
            id = Integer.parseInt(idStr);
            delta = Integer.parseInt(deltaStr);
        } catch (NumberFormatException e) {
            respondJson(ex, 200, "{\"ok\":false,\"message\":\"Bad request.\"}");
            return;
        }

        try {
            if ("AC".equals(itemType)) {
                AirConditioningUnit u = inventoryDao.adjustUnitQuantity(id, delta);
                activityLog.log(username, delta > 0 ? "SCAN_ADD" : "SCAN_REMOVE",
                        "Scanned " + u.getBrand() + " " + u.getModelNo() + " (" + (delta > 0 ? "+" : "") + delta + ")");
                respondJson(ex, 200, "{\"ok\":true,\"quantity\":" + u.getQuantity() + ",\"status\":\"" + jsonEscape(u.getStatus()) + "\"}");
            } else if ("MATERIAL".equals(itemType)) {
                Material m = inventoryDao.adjustMaterialQuantity(id, delta);
                activityLog.log(username, delta > 0 ? "SCAN_ADD" : "SCAN_REMOVE",
                        "Scanned " + m.getName() + " (" + (delta > 0 ? "+" : "") + delta + ")");
                respondJson(ex, 200, "{\"ok\":true,\"quantity\":" + m.getQuantity() + ",\"status\":\"\"}");
            } else {
                respondJson(ex, 200, "{\"ok\":false,\"message\":\"Unknown item type.\"}");
            }
        } catch (SQLException e) {
            respondJson(ex, 200, "{\"ok\":false,\"message\":\"Database error updating that item.\"}");
        }
    }

    // ================= tiny helpers (no JSON library dependency needed for payloads this simple) =================

    private static final Pattern JSON_PAIR = Pattern.compile("\"(\\w+)\"\\s*:\\s*(?:\"([^\"]*)\"|([0-9.\\-]+))");

    private Map<String, String> readJsonBody(HttpExchange ex) throws IOException {
        byte[] raw = ex.getRequestBody().readAllBytes();
        String text = new String(raw, StandardCharsets.UTF_8);
        Map<String, String> map = new ConcurrentHashMap<>();
        Matcher m = JSON_PAIR.matcher(text);
        while (m.find()) {
            String key = m.group(1);
            String value = m.group(2) != null ? m.group(2) : m.group(3);
            map.put(key, value == null ? "" : value);
        }
        return map;
    }

    private String jsonEscape(String s) {
        return s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private void respondJson(HttpExchange ex, int status, String json) throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        ex.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(bytes);
        }
    }

    private void respondHtml(HttpExchange ex, int status, String html) throws IOException {
        byte[] bytes = html.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
        ex.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(bytes);
        }
    }

    // ================= the mobile page itself =================

    private static final String PAGE_HTML = """
            <!DOCTYPE html>
            <html>
            <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>KhierKian Scanner</title>
            <script src="https://cdn.jsdelivr.net/npm/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
            <style>
              * { box-sizing: border-box; }
              body { margin:0; font-family: -apple-system, 'Segoe UI', sans-serif; background:#021125;
                     color:#ebeef5; min-height:100vh; display:flex; flex-direction:column; align-items:center; padding:24px 16px; }
              h1 { font-size:18px; margin:8px 0 20px; text-align:center; }
              .card { background:#1a2f61; border-radius:18px; padding:24px; width:100%; max-width:380px;
                      box-shadow: 0 0 0 1px rgba(120,170,230,0.3); }
              input { width:100%; padding:12px 14px; margin:6px 0 14px; border-radius:12px; border:1px solid rgba(255,255,255,0.2);
                      background:#343e4e; color:#fff; font-size:15px; }
              label { font-size:13px; font-weight:600; color:#c9d3e6; }
              button { width:100%; padding:13px; border-radius:12px; border:none; font-size:15px; font-weight:700;
                       cursor:pointer; margin-top:6px; }
              .btn-primary { background:#4084d6; color:#fff; }
              .btn-add { background:#4caf50; color:#fff; }
              .btn-remove { background:#e53935; color:#fff; }
              .btn-secondary { background:#3a4666; color:#ebeef5; }
              #reader { width:100%; border-radius:14px; overflow:hidden; margin-bottom:14px; }
              .msg { color:#ff8a80; font-size:13px; min-height:18px; margin:-6px 0 10px; }
              .hidden { display:none; }
              .item-name { font-size:20px; font-weight:700; margin-bottom:2px; }
              .item-qty { font-size:15px; color:#a0a8c0; margin-bottom:16px; }
              .row { display:flex; gap:10px; }
            </style>
            </head>
            <body>
            <h1>KhierKian Air-Conditioning Services — Scanner</h1>

            <div class="card" id="loginCard">
              <label>Username</label>
              <input id="username" autocomplete="username">
              <label>Password</label>
              <input id="password" type="password" autocomplete="current-password">
              <div class="msg" id="loginMsg"></div>
              <button class="btn-primary" onclick="login()">Log In</button>
            </div>

            <div class="card hidden" id="scanCard">
              <div id="reader"></div>
              <div class="msg" id="scanMsg"></div>
              <button class="btn-add hidden" id="registerBtn" onclick="registerNew()">+ Add as New AC Unit</button>
              <button class="btn-secondary hidden" id="cancelRegisterBtn" onclick="cancelRegister()">Not an AC unit - Scan Again</button>
              <button class="btn-secondary" onclick="logout()">Log Out</button>
            </div>

            <div class="card hidden" id="resultCard">
              <div class="item-name" id="resultName"></div>
              <div class="item-qty" id="resultQty"></div>
              <div class="row">
                <button class="btn-add" onclick="adjust(1)">+1 Received</button>
                <button class="btn-remove" onclick="adjust(-1)">-1 Used</button>
              </div>
              <button class="btn-secondary" onclick="backToScan()">Scan Next</button>
            </div>

            <script>
              let token = null;
              let currentItem = null;
              let qrScanner = null;
              let lastScannedCode = null;

              /** POSTs JSON with a couple of automatic retries — a single WiFi hiccup shouldn't need a manual redo. */
              async function fetchJson(url, body, retries) {
                if (retries === undefined) retries = 2;
                let lastError;
                for (let attempt = 0; attempt <= retries; attempt++) {
                  try {
                    const res = await fetch(url, { method: 'POST', body: JSON.stringify(body) });
                    return await res.json();
                  } catch (e) {
                    lastError = e;
                    if (attempt < retries) await new Promise(r => setTimeout(r, 600));
                  }
                }
                throw lastError;
              }

              async function login() {
                const username = document.getElementById('username').value.trim();
                const password = document.getElementById('password').value;
                const msg = document.getElementById('loginMsg');
                msg.textContent = 'Checking...';
                try {
                  const data = await fetchJson('/api/login', {username, password});
                  if (!data.ok) { msg.textContent = data.message; return; }
                  token = data.token;
                  msg.textContent = '';
                  document.getElementById('loginCard').classList.add('hidden');
                  document.getElementById('scanCard').classList.remove('hidden');
                  startScanner();
                } catch (e) {
                  msg.innerHTML = 'Could not reach the server. <a href="#" onclick="login();return false;" style="color:#8ab4f8;">Tap to retry</a>';
                }
              }

              function logout() {
                token = null;
                document.getElementById('registerBtn').classList.add('hidden');
                document.getElementById('cancelRegisterBtn').classList.add('hidden');
                document.getElementById('scanMsg').textContent = '';
                if (qrScanner) { qrScanner.stop().catch(()=>{}); }
                document.getElementById('scanCard').classList.add('hidden');
                document.getElementById('resultCard').classList.add('hidden');
                document.getElementById('loginCard').classList.remove('hidden');
              }

              function startScanner() {
                qrScanner = new Html5Qrcode("reader");
                qrScanner.start(
                  { facingMode: "environment" },
                  { fps: 10, qrbox: 240 },
                  onScanSuccess,
                  () => {}
                ).catch(err => {
                  document.getElementById('scanMsg').textContent = 'Camera error: ' + err;
                });
              }

              async function onScanSuccess(decodedText) {
                if (!token) return;
                lastScannedCode = decodedText;
                await qrScanner.pause(true);
                await lookUpCode(decodedText);
              }

              async function lookUpCode(code) {
                const msg = document.getElementById('scanMsg');
                msg.textContent = 'Looking up...';
                try {
                  const data = await fetchJson('/api/scan', { token, code });
                  if (!data.ok && data.notFound) {
                    // Unknown code: offer one-tap registration instead of just failing.
                    msg.textContent = 'New code: ' + data.code + ' - not in inventory yet.';
                    document.getElementById('registerBtn').classList.remove('hidden');
                    document.getElementById('cancelRegisterBtn').classList.remove('hidden');
                    return;
                  }
                  if (!data.ok) {
                    msg.textContent = data.message;
                    setTimeout(() => { qrScanner.resume(); msg.textContent = ''; }, 1500);
                    return;
                  }
                  currentItem = data;
                  document.getElementById('resultName').textContent = data.name;
                  document.getElementById('resultQty').textContent =
                    'Current quantity: ' + data.quantity + (data.status ? ' — ' + data.status : '');
                  document.getElementById('scanCard').classList.add('hidden');
                  document.getElementById('resultCard').classList.remove('hidden');
                } catch (e) {
                  msg.innerHTML = 'Could not reach the server. '
                    + '<a href="#" onclick="lookUpCode(lastScannedCode);return false;" style="color:#ff8a80;">Tap to retry</a>';
                }
              }

              async function adjust(delta) {
                if (!currentItem) return;
                const qtyLabel = document.getElementById('resultQty');
                try {
                  const data = await fetchJson('/api/adjust', {
                    token, itemType: currentItem.itemType, id: currentItem.id, delta
                  });
                  if (data.ok) {
                    qtyLabel.textContent = 'Current quantity: ' + data.quantity + (data.status ? ' — ' + data.status : '');
                  } else {
                    qtyLabel.textContent = data.message;
                  }
                } catch (e) {
                  qtyLabel.innerHTML = 'Could not reach the server. '
                    + '<a href="#" onclick="adjust(' + delta + ');return false;" style="color:#ff8a80;">Tap to retry</a>';
                }
              }

              function cancelRegister() {
                document.getElementById('registerBtn').classList.add('hidden');
                document.getElementById('cancelRegisterBtn').classList.add('hidden');
                document.getElementById('scanMsg').textContent = '';
                qrScanner.resume();
              }

              async function registerNew() {
                const msg = document.getElementById('scanMsg');
                msg.textContent = 'Adding...';
                try {
                  const data = await fetchJson('/api/register', { token, code: lastScannedCode });
                  if (!data.ok) { msg.textContent = data.message; return; }
                  document.getElementById('registerBtn').classList.add('hidden');
                  document.getElementById('cancelRegisterBtn').classList.add('hidden');
                  msg.textContent = '';
                  currentItem = data;
                  document.getElementById('resultName').textContent = data.name + ' (new - add details on desktop)';
                  document.getElementById('resultQty').textContent =
                    'Current quantity: ' + data.quantity + (data.status ? ' - ' + data.status : '');
                  document.getElementById('scanCard').classList.add('hidden');
                  document.getElementById('resultCard').classList.remove('hidden');
                } catch (e) {
                  msg.innerHTML = 'Could not reach the server. '
                    + '<a href="#" onclick="registerNew();return false;" style="color:#ff8a80;">Tap to retry</a>';
                }
              }

              function backToScan() {
                document.getElementById('registerBtn').classList.add('hidden');
                document.getElementById('cancelRegisterBtn').classList.add('hidden');
                document.getElementById('resultCard').classList.add('hidden');
                document.getElementById('scanCard').classList.remove('hidden');
                document.getElementById('scanMsg').textContent = '';
                qrScanner.resume();
              }
            </script>
            </body>
            </html>
            """;
}
