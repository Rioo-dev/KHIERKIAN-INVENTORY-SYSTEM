package com.khierkian.model;

import java.sql.Timestamp;

public class LoginRecord {
    private String lastName;
    private String firstName;
    private String role;
    private Timestamp loginTime;
    private String status;
    private String ipAddress;

    public LoginRecord(String lastName, String firstName, String role,
                        Timestamp loginTime, String status, String ipAddress) {
        this.lastName = lastName;
        this.firstName = firstName;
        this.role = role;
        this.loginTime = loginTime;
        this.status = status;
        this.ipAddress = ipAddress;
    }

    public String getLastName() { return lastName; }
    public String getFirstName() { return firstName; }
    public String getRole() { return role; }
    public Timestamp getLoginTime() { return loginTime; }
    public String getStatus() { return status; }
    public String getIpAddress() { return ipAddress; }
}
