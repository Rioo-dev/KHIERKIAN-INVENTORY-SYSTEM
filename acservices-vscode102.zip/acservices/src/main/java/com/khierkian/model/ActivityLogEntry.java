package com.khierkian.model;

import java.sql.Timestamp;

public class ActivityLogEntry {
    private String username;
    private String action;
    private String description;
    private Timestamp actionTime;

    public ActivityLogEntry(String username, String action, String description, Timestamp actionTime) {
        this.username = username;
        this.action = action;
        this.description = description;
        this.actionTime = actionTime;
    }

    public String getUsername() { return username; }
    public String getAction() { return action; }
    public String getDescription() { return description; }
    public Timestamp getActionTime() { return actionTime; }
}
