package com.khierkian.model;

import java.sql.Timestamp;

public class AirConditioningUnit {
    private int id;
    private String brand;
    private String modelNo;
    private String specifications;
    private String type;
    private int quantity;
    private String status;
    private String serialNo;
    private Timestamp dateArrived;

    public AirConditioningUnit(int id, String brand, String modelNo, String specifications,
                                String type, int quantity, String status, String serialNo, Timestamp dateArrived) {
        this.id = id;
        this.brand = brand;
        this.modelNo = modelNo;
        this.specifications = specifications;
        this.type = type;
        this.quantity = quantity;
        this.status = status;
        this.serialNo = serialNo;
        this.dateArrived = dateArrived;
    }

    public int getId() { return id; }
    public String getBrand() { return brand; }
    public String getModelNo() { return modelNo; }
    public String getSpecifications() { return specifications; }
    public String getType() { return type; }
    public int getQuantity() { return quantity; }
    public String getStatus() { return status; }
    public String getSerialNo() { return serialNo; }
    public Timestamp getDateArrived() { return dateArrived; }
}
