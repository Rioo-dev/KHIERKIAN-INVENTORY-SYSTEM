package com.khierkian.model;

public class User {
    private int id;
    private String lastName;
    private String firstName;
    private String username;
    private String role;
    private String status;
    private String phone;

    public User(int id, String lastName, String firstName, String username, String role, String status, String phone) {
        this.id = id;
        this.lastName = lastName;
        this.firstName = firstName;
        this.username = username;
        this.role = role;
        this.status = status;
        this.phone = phone;
    }

    public int getId() { return id; }
    public String getLastName() { return lastName; }
    public String getFirstName() { return firstName; }
    public String getUsername() { return username; }
    public String getRole() { return role; }
    public String getStatus() { return status; }
    public String getPhone() { return phone; }
}
