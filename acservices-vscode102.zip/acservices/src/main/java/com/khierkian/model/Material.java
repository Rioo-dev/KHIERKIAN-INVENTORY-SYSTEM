package com.khierkian.model;

import java.sql.Timestamp;

public class Material {
    private int id;
    private String name;
    private String unitOfMeasure;
    private int quantity;
    private String type;
    private String acType;
    private Timestamp dateArrived;
    private String barcode;

    public Material(int id, String name, String unitOfMeasure, int quantity, String type, String acType,
                     Timestamp dateArrived, String barcode) {
        this.id = id;
        this.name = name;
        this.unitOfMeasure = unitOfMeasure;
        this.quantity = quantity;
        this.type = type;
        this.acType = acType;
        this.dateArrived = dateArrived;
        this.barcode = barcode;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getUnitOfMeasure() { return unitOfMeasure; }
    public int getQuantity() { return quantity; }
    public String getType() { return type; }
    public String getAcType() { return acType; }
    public Timestamp getDateArrived() { return dateArrived; }
    public String getBarcode() { return barcode; }
}
