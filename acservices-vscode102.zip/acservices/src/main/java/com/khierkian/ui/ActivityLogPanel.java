package com.khierkian.ui;

import com.khierkian.dao.ActivityLogDAO;
import com.khierkian.model.ActivityLogEntry;
import com.khierkian.ui.components.DateTimeUtil;
import com.khierkian.ui.components.TableStyler;
import com.khierkian.ui.components.Theme;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.List;

public class ActivityLogPanel extends JPanel {

    private final ActivityLogDAO dao = new ActivityLogDAO();

    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"Staff", "Action", "Details", "Date", "Time"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);

    public ActivityLogPanel() {
        setLayout(new BorderLayout());
        setBackground(Theme.CONTENT_BG);
        setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));

        JLabel heading = new JLabel("Activity Log");
        heading.setFont(Theme.FONT_TITLE);
        heading.setForeground(Theme.TEXT_ON_LIGHT);
        add(heading, BorderLayout.NORTH);

        JLabel subtitle = new JLabel("Every inventory add, edit, or delete made by staff accounts.");
        subtitle.setForeground(Theme.TEXT_MUTED_ON_LIGHT);
        subtitle.setFont(Theme.FONT_BODY);
        subtitle.setBorder(BorderFactory.createEmptyBorder(30, 0, 8, 0));

        JPanel center = new JPanel(new BorderLayout());
        center.setOpaque(false);
        center.add(subtitle, BorderLayout.NORTH);

        TableStyler.style(table);
        TableStyler.setColumnWidths(table, 110, 110, 260, 110, 100);
        table.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && table.getSelectedRow() >= 0) {
                    showDetails(table.getSelectedRow());
                }
            }
        });
        center.add(new JScrollPane(table), BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);
    }

    private void showDetails(int row) {
        String staff = String.valueOf(model.getValueAt(row, 0));
        String action = String.valueOf(model.getValueAt(row, 1));
        String details = String.valueOf(model.getValueAt(row, 2));
        String date = String.valueOf(model.getValueAt(row, 3));
        String time = String.valueOf(model.getValueAt(row, 4));

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        content.add(detailLine("Staff", staff));
        content.add(detailLine("Action", action));
        content.add(detailLine("Date", date));
        content.add(detailLine("Time", time));
        content.add(Box.createVerticalStrut(6));
        JLabel detailsLabel = new JLabel("Details");
        detailsLabel.setFont(Theme.FONT_LABEL);
        detailsLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        JTextArea detailsArea = new JTextArea(details);
        detailsArea.setLineWrap(true);
        detailsArea.setWrapStyleWord(true);
        detailsArea.setEditable(false);
        detailsArea.setFont(Theme.FONT_BODY);
        detailsArea.setBackground(content.getBackground());
        detailsArea.setAlignmentX(Component.LEFT_ALIGNMENT);
        detailsArea.setMaximumSize(new Dimension(360, 200));
        content.add(detailsLabel);
        content.add(detailsArea);

        JOptionPane.showMessageDialog(this, content, "Activity Log Entry", JOptionPane.PLAIN_MESSAGE);
    }

    private JComponent detailLine(String label, String value) {
        JPanel row = new JPanel(new BorderLayout(10, 0));
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        row.setMaximumSize(new Dimension(360, 26));
        JLabel labelComp = new JLabel(label);
        labelComp.setFont(Theme.FONT_LABEL);
        labelComp.setPreferredSize(new Dimension(60, 20));
        row.add(labelComp, BorderLayout.WEST);
        row.add(new JLabel(value), BorderLayout.CENTER);
        return row;
    }

    public void refresh() {
        new SwingWorker<List<ActivityLogEntry>, Void>() {
            SQLException failure;
            @Override protected List<ActivityLogEntry> doInBackground() {
                try { return dao.findAll(); } catch (SQLException e) { failure = e; return List.of(); }
            }
            @Override protected void done() {
                if (failure != null) {
                    JOptionPane.showMessageDialog(ActivityLogPanel.this,
                            "Database error: " + failure.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                try {
                    model.setRowCount(0);
                    for (ActivityLogEntry entry : get()) {
                        model.addRow(new Object[]{
                                entry.getUsername(), entry.getAction(), entry.getDescription(),
                                DateTimeUtil.formatDate(entry.getActionTime()), DateTimeUtil.formatTime(entry.getActionTime())
                        });
                    }
                } catch (Exception ignored) { }
            }
        }.execute();
    }
}
