package com.khierkian.ui.components;

import javax.swing.*;
import java.awt.*;

/**
 * A small card with a title and a body area. Body can be swapped between
 * a big number (headline stat) or a short list of lines (e.g. "Out of stock").
 */
public class StatCard extends JPanel {

    private final JLabel titleLabel;
    private final JLabel bodyLabel = new JLabel();

    public StatCard(String title) {
        setLayout(new BorderLayout());
        setBackground(Theme.CARD_BG);
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 0, 0, Theme.ACCENT),
                BorderFactory.createEmptyBorder(16, 18, 16, 18)));

        titleLabel = new JLabel(title.toUpperCase());
        titleLabel.setFont(Theme.FONT_CARD_TITLE);
        titleLabel.setForeground(Theme.TEXT_MUTED);

        bodyLabel.setVerticalAlignment(SwingConstants.TOP);
        bodyLabel.setForeground(Theme.TEXT_LIGHT);

        add(titleLabel, BorderLayout.NORTH);
        add(bodyLabel, BorderLayout.CENTER);
    }

    /** Show one big, centered number (e.g. total units in stock). */
    public void setStatValue(String value) {
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        bodyLabel.setForeground(Theme.TEXT_LIGHT);
        bodyLabel.setHorizontalAlignment(SwingConstants.CENTER);
        bodyLabel.setVerticalAlignment(SwingConstants.CENTER);
        bodyLabel.setText("<html><body style='width:100%; text-align:center;'>"
                + "<div style='font-size:56px; font-weight:bold; padding-top:10px;'>"
                + escape(value) + "</div></body></html>");
    }

    /** Show a big number plus a short list underneath (e.g. total + recent items). */
    public void setStatWithLines(String value, java.util.List<String> lines) {
        bodyLabel.setFont(Theme.FONT_BODY);
        StringBuilder html = new StringBuilder("<html><body style='font-family:Segoe UI;'>");
        html.append("<div style='font-size:30px; font-weight:bold; color:#").append(toHex(Theme.TEXT_LIGHT))
            .append("; margin-bottom:10px;'>").append(escape(value)).append("</div>");
        for (String line : lines) {
            html.append("<div style='font-size:15px; color:#").append(toHex(Theme.TEXT_MUTED))
                .append("; margin-bottom:5px;'>&bull; ").append(escape(line)).append("</div>");
        }
        html.append("</body></html>");
        bodyLabel.setText(html.toString());
    }

    /** Show a short bulleted list; shows a muted placeholder if empty. */
    public void setLines(java.util.List<String> lines, String emptyText, Color emptyColor) {
        bodyLabel.setFont(Theme.FONT_BODY);
        StringBuilder html = new StringBuilder("<html><body style='font-family:Segoe UI; font-size:15px;'>");
        if (lines.isEmpty()) {
            html.append("<span style='color:#").append(toHex(emptyColor)).append(";'>")
                .append(escape(emptyText)).append("</span>");
        } else {
            for (String line : lines) {
                html.append("<div style='margin-bottom:8px; color:#").append(toHex(Theme.TEXT_LIGHT)).append(";'>")
                    .append("&bull; ").append(escape(line)).append("</div>");
            }
        }
        html.append("</body></html>");
        bodyLabel.setText(html.toString());
    }

    private static String toHex(Color c) {
        return String.format("%02x%02x%02x", c.getRed(), c.getGreen(), c.getBlue());
    }

    private static String escape(String s) {
        return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
