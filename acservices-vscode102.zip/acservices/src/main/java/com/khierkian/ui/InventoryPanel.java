package com.khierkian.ui;

import com.khierkian.dao.ActivityLogDAO;
import com.khierkian.dao.InventoryDAO;
import com.khierkian.model.AirConditioningUnit;
import com.khierkian.model.Material;
import com.khierkian.session.Session;
import com.khierkian.ui.components.DateTimeUtil;
import com.khierkian.ui.components.TableStyler;
import com.khierkian.ui.components.Theme;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class InventoryPanel extends JPanel {

    private final InventoryDAO dao = new InventoryDAO();
    private final ActivityLogDAO activityLog = new ActivityLogDAO();
    // Arrival timestamps are shown via DateTimeUtil (GMT+8, numeric only).
    private final boolean editable = !Session.isAdmin(); // Administrators are viewers only.

    // ----- AC Units tab -----
    private final DefaultTableModel acModel = new DefaultTableModel(
            new String[]{"ID", "Brand", "Model No.", "Specifications", "Type", "Qty", "Status", "Serial No.", "Arrived"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable acTable = new JTable(acModel);
    private JButton acDeleteBtn;
    private final JTextField acSearch = new JTextField();
    private final JComboBox<String> acTypeFilter = new JComboBox<>(
            new String[]{"All", "Inverter", "Non-Inverter", "Split Type", "Window Type", "Portable", "Unspecified"});
    private final JComboBox<String> acStatusFilter = new JComboBox<>(
            new String[]{"All", "Available", "Low Stock", "Out of Stock"});
    private final JComboBox<String> acArrivalFilter = new JComboBox<>(
            new String[]{"Any time", "Today", "Last 7 days", "Last 30 days"});

    // ----- Materials tab -----
    private final DefaultTableModel matModel = new DefaultTableModel(
            new String[]{"ID", "Name", "Unit", "Qty", "Type", "AC Type", "Arrived", "Barcode"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable matTable = new JTable(matModel);
    private JButton matDeleteBtn;
    private final JTextField matSearch = new JTextField();
    private final JComboBox<String> matUnitFilter = new JComboBox<>(
            new String[]{"All", "pcs", "meters", "rolls", "kg", "liters", "box", "set"});
    private final JComboBox<String> matTypeFilter = new JComboBox<>(
            new String[]{"All", "Piping", "Wiring", "Insulation", "Fastener", "Refrigerant", "Other"});
    private final JComboBox<String> matAcTypeFilter = new JComboBox<>(
            new String[]{"All", "Any", "Inverter", "Non-Inverter", "Split Type", "Window Type", "Portable"});

    public InventoryPanel() {
        setLayout(new BorderLayout());
        setBackground(Theme.CONTENT_BG);
        setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));

        JLabel heading = new JLabel("Inventory" + (editable ? "" : "  (view only)"));
        heading.setFont(Theme.FONT_TITLE);
        heading.setForeground(Theme.TEXT_ON_LIGHT);
        heading.setBorder(BorderFactory.createEmptyBorder(0, 0, 16, 0));
        add(heading, BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Air Conditioning Units", buildAcTab());
        tabs.addTab("Materials", buildMaterialsTab());
        add(tabs, BorderLayout.CENTER);
    }

    // ================= AC Units tab =================

    private JComponent buildAcTab() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setOpaque(false);

        JPanel north = new JPanel();
        north.setLayout(new BoxLayout(north, BoxLayout.Y_AXIS));
        north.setOpaque(false);

        JPanel filterRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 4));
        filterRow.setOpaque(false);
        acSearch.setPreferredSize(new Dimension(160, 28));
        filterRow.add(labeled("Search:", acSearch));
        filterRow.add(labeled("Type:", acTypeFilter));
        filterRow.add(labeled("Status:", acStatusFilter));
        filterRow.add(labeled("Arrived:", acArrivalFilter));
        JButton applyBtn = new JButton("Apply");
        JButton resetBtn = new JButton("Reset");
        applyBtn.addActionListener(e -> loadAcUnits());
        resetBtn.addActionListener(e -> {
            acSearch.setText("");
            acTypeFilter.setSelectedIndex(0);
            acStatusFilter.setSelectedIndex(0);
            acArrivalFilter.setSelectedIndex(0);
            loadAcUnits();
        });
        acSearch.addActionListener(e -> loadAcUnits());
        filterRow.add(applyBtn);
        filterRow.add(resetBtn);
        north.add(filterRow);

        if (editable) {
            JButton addBtn = new JButton("+ Add New Unit");
            acDeleteBtn = new JButton("Delete Selected");
            acDeleteBtn.setEnabled(false);
            addBtn.addActionListener(e -> openAcDialog(null));
            acDeleteBtn.addActionListener(e -> deleteAcUnit());

            JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
            toolbar.setOpaque(false);
            toolbar.add(addBtn);
            toolbar.add(acDeleteBtn);
            north.add(toolbar);
        } else {
            JLabel note = new JLabel("Double-click a row to view details. Staff accounts manage inventory changes.");
            note.setForeground(Theme.TEXT_MUTED_ON_LIGHT);
            note.setFont(Theme.FONT_BODY);
            note.setBorder(BorderFactory.createEmptyBorder(2, 4, 4, 4));
            north.add(note);
        }
        panel.add(north, BorderLayout.NORTH);

        TableStyler.style(acTable);
        TableStyler.setColumnWidths(acTable, 40, 110, 110, 170, 100, 50, 100, 110, 170);
        acTable.getSelectionModel().addListSelectionListener(e -> {
            if (editable) {
                acDeleteBtn.setEnabled(acTable.getSelectedRow() >= 0);
            }
        });
        acTable.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && acTable.getSelectedRow() >= 0) {
                    openAcDialog(selectedAcUnit());
                }
            }
        });
        panel.add(new JScrollPane(acTable), BorderLayout.CENTER);
        return panel;
    }

    private JPanel labeled(String text, JComponent field) {
        JPanel p = new JPanel(new BorderLayout(4, 0));
        p.setOpaque(false);
        JLabel l = new JLabel(text);
        l.setForeground(Theme.TEXT_MUTED_ON_LIGHT);
        l.setFont(Theme.FONT_BODY);
        p.add(l, BorderLayout.WEST);
        p.add(field, BorderLayout.CENTER);
        return p;
    }

    private AirConditioningUnit selectedAcUnit() {
        int row = acTable.getSelectedRow();
        if (row < 0) return null;
        return new AirConditioningUnit(
                (Integer) acModel.getValueAt(row, 0),
                String.valueOf(acModel.getValueAt(row, 1)),
                String.valueOf(acModel.getValueAt(row, 2)),
                String.valueOf(acModel.getValueAt(row, 3)),
                String.valueOf(acModel.getValueAt(row, 4)),
                (Integer) acModel.getValueAt(row, 5),
                String.valueOf(acModel.getValueAt(row, 6)),
                String.valueOf(acModel.getValueAt(row, 7)),
                null);
    }

    /** Opens a popup dialog for adding a new unit, or editing/viewing one if `existing` is non-null. */
    private void openAcDialog(AirConditioningUnit existing) {
        boolean isNew = existing == null;
        boolean canEdit = editable; // false for Administrators — dialog opens read-only
        JDialog dialog = new JDialog(SwingUtilities.getWindowAncestor(this),
                isNew ? "Add Air Conditioning Unit" : (canEdit ? "Edit Air Conditioning Unit" : "View Air Conditioning Unit"),
                Dialog.ModalityType.APPLICATION_MODAL);
        dialog.setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(20, 24, 12, 24));
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(6, 6, 6, 6);
        gc.fill = GridBagConstraints.HORIZONTAL;

        JTextField txtBrand = new JTextField(!isNew ? existing.getBrand() : "", 18);
        JTextField txtModelNo = new JTextField(!isNew ? existing.getModelNo() : "", 18);
        JTextField txtSpecs = new JTextField(!isNew ? existing.getSpecifications() : "", 18);
        JComboBox<String> cbType = new JComboBox<>(new String[]{"Inverter", "Non-Inverter", "Split Type", "Window Type", "Portable", "Unspecified"});
        JSpinner spQuantity = new JSpinner(new SpinnerNumberModel(!isNew ? existing.getQuantity() : 0, 0, 100000, 1));
        JComboBox<String> cbStatus = new JComboBox<>(new String[]{"Available", "Low Stock", "Out of Stock"});
        JTextField txtSerialNo = new JTextField(!isNew ? existing.getSerialNo() : "", 18);
        if (!isNew) {
            cbType.setSelectedItem(existing.getType());
            cbStatus.setSelectedItem(existing.getStatus());
        }

        for (JComponent c : List.of(txtBrand, txtModelNo, txtSpecs, cbType, spQuantity, cbStatus, txtSerialNo)) {
            c.setEnabled(canEdit);
        }

        int row = 0;
        row = addFormRow(form, gc, row, "Brand", txtBrand);
        row = addFormRow(form, gc, row, "Model No.", txtModelNo);
        row = addFormRow(form, gc, row, "Specifications", txtSpecs);
        row = addFormRow(form, gc, row, "Type", cbType);
        row = addFormRow(form, gc, row, "Quantity", spQuantity);
        row = addFormRow(form, gc, row, "Status", cbStatus);

        JPanel serialRow = new JPanel(new BorderLayout(6, 0));
        JButton genBtn = new JButton("Generate");
        genBtn.setEnabled(canEdit);
        genBtn.addActionListener(e -> txtSerialNo.setText("AC-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase()));
        serialRow.add(txtSerialNo, BorderLayout.CENTER);
        serialRow.add(genBtn, BorderLayout.EAST);
        addFormRow(form, gc, row, "Serial No.", serialRow);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        if (!canEdit) {
            JButton close = new JButton("Close");
            close.addActionListener(e -> dialog.dispose());
            buttons.add(close);
        } else {
            JButton cancel = new JButton("Cancel");
            JButton save = new JButton(isNew ? "Add Unit" : "Save Changes");
            cancel.addActionListener(e -> dialog.dispose());
            save.addActionListener(e -> {
                if (txtBrand.getText().trim().isEmpty() || txtModelNo.getText().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "Brand and Model No. are required.");
                    return;
                }
                String brand = txtBrand.getText().trim();
                String modelNo = txtModelNo.getText().trim();
                String specs = txtSpecs.getText().trim();
                String type = (String) cbType.getSelectedItem();
                int qty = (Integer) spQuantity.getValue();
                String status = (String) cbStatus.getSelectedItem();
                String serial = txtSerialNo.getText().trim();

                runAsync(() -> {
                    if (isNew) {
                        dao.insertUnit(brand, modelNo, specs, type, qty, status, serial);
                        activityLog.log(Session.getUsername(), "ADD_AC", "Added AC unit " + brand + " " + modelNo + " (qty " + qty + ")");
                    } else {
                        dao.updateUnit(existing.getId(), brand, modelNo, specs, type, qty, status, serial);
                        activityLog.log(Session.getUsername(), "UPDATE_AC", "Updated AC unit " + brand + " " + modelNo);
                    }
                }, () -> {
                    dialog.dispose();
                    loadAcUnits();
                });
            });
            buttons.add(cancel);
            buttons.add(save);
            dialog.getRootPane().setDefaultButton(save);
        }

        dialog.add(form, BorderLayout.CENTER);
        dialog.add(buttons, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void deleteAcUnit() {
        AirConditioningUnit unit = selectedAcUnit();
        if (unit == null) return;
        if (JOptionPane.showConfirmDialog(this, "Delete " + unit.getBrand() + " " + unit.getModelNo() + "?",
                "Confirm", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        runAsync(() -> {
            dao.deleteUnit(unit.getId());
            activityLog.log(Session.getUsername(), "DELETE_AC", "Deleted AC unit " + unit.getBrand() + " " + unit.getModelNo());
        }, this::loadAcUnits);
    }

    private void loadAcUnits() {
        String keyword = acSearch.getText().trim();
        String type = (String) acTypeFilter.getSelectedItem();
        String status = (String) acStatusFilter.getSelectedItem();
        InventoryDAO.ArrivalFilter arrival = switch (acArrivalFilter.getSelectedIndex()) {
            case 1 -> InventoryDAO.ArrivalFilter.TODAY;
            case 2 -> InventoryDAO.ArrivalFilter.LAST_7_DAYS;
            case 3 -> InventoryDAO.ArrivalFilter.LAST_30_DAYS;
            default -> InventoryDAO.ArrivalFilter.ANY;
        };

        new SwingWorker<List<AirConditioningUnit>, Void>() {
            SQLException failure;
            @Override protected List<AirConditioningUnit> doInBackground() {
                try { return dao.filterUnits(keyword, type, status, arrival); } catch (SQLException e) { failure = e; return List.of(); }
            }
            @Override protected void done() {
                if (failure != null) { showDbError(failure); return; }
                acModel.setRowCount(0);
                try {
                    for (AirConditioningUnit u : get()) {
                        acModel.addRow(new Object[]{u.getId(), u.getBrand(), u.getModelNo(), u.getSpecifications(),
                                u.getType(), u.getQuantity(), u.getStatus(), u.getSerialNo(),
                                DateTimeUtil.formatDateTime(u.getDateArrived())});
                    }
                } catch (Exception ignored) { }
                if (editable) acDeleteBtn.setEnabled(false);
            }
        }.execute();
    }

    // ================= Materials tab =================

    private JComponent buildMaterialsTab() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setOpaque(false);

        JPanel north = new JPanel();
        north.setLayout(new BoxLayout(north, BoxLayout.Y_AXIS));
        north.setOpaque(false);

        JPanel filterRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 4));
        filterRow.setOpaque(false);
        matSearch.setPreferredSize(new Dimension(160, 28));
        filterRow.add(labeled("Search:", matSearch));
        filterRow.add(labeled("Unit:", matUnitFilter));
        filterRow.add(labeled("Type:", matTypeFilter));
        filterRow.add(labeled("AC Type:", matAcTypeFilter));
        JButton applyBtn = new JButton("Apply");
        JButton resetBtn = new JButton("Reset");
        applyBtn.addActionListener(e -> loadMaterials());
        resetBtn.addActionListener(e -> {
            matSearch.setText("");
            matUnitFilter.setSelectedIndex(0);
            matTypeFilter.setSelectedIndex(0);
            matAcTypeFilter.setSelectedIndex(0);
            loadMaterials();
        });
        matSearch.addActionListener(e -> loadMaterials());
        filterRow.add(applyBtn);
        filterRow.add(resetBtn);
        north.add(filterRow);

        if (editable) {
            JButton addBtn = new JButton("+ Add New Material");
            matDeleteBtn = new JButton("Delete Selected");
            matDeleteBtn.setEnabled(false);
            addBtn.addActionListener(e -> openMaterialDialog(null));
            matDeleteBtn.addActionListener(e -> deleteMaterial());

            JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
            toolbar.setOpaque(false);
            toolbar.add(addBtn);
            toolbar.add(matDeleteBtn);
            north.add(toolbar);
        } else {
            JLabel note = new JLabel("Double-click a row to view details. Staff accounts manage inventory changes.");
            note.setForeground(Theme.TEXT_MUTED_ON_LIGHT);
            note.setFont(Theme.FONT_BODY);
            note.setBorder(BorderFactory.createEmptyBorder(2, 4, 4, 4));
            north.add(note);
        }
        panel.add(north, BorderLayout.NORTH);

        TableStyler.style(matTable);
        TableStyler.setColumnWidths(matTable, 40, 150, 80, 60, 110, 110, 170, 130);
        matTable.getSelectionModel().addListSelectionListener(e -> {
            if (editable) {
                matDeleteBtn.setEnabled(matTable.getSelectedRow() >= 0);
            }
        });
        matTable.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && matTable.getSelectedRow() >= 0) {
                    openMaterialDialog(selectedMaterial());
                }
            }
        });
        panel.add(new JScrollPane(matTable), BorderLayout.CENTER);
        return panel;
    }

    private Material selectedMaterial() {
        int row = matTable.getSelectedRow();
        if (row < 0) return null;
        return new Material(
                (Integer) matModel.getValueAt(row, 0),
                String.valueOf(matModel.getValueAt(row, 1)),
                String.valueOf(matModel.getValueAt(row, 2)),
                (Integer) matModel.getValueAt(row, 3),
                String.valueOf(matModel.getValueAt(row, 4)),
                String.valueOf(matModel.getValueAt(row, 5)),
                null,
                String.valueOf(matModel.getValueAt(row, 7)));
    }

    private void openMaterialDialog(Material existing) {
        boolean isNew = existing == null;
        boolean canEdit = editable;
        JDialog dialog = new JDialog(SwingUtilities.getWindowAncestor(this),
                isNew ? "Add Material" : (canEdit ? "Edit Material" : "View Material"),
                Dialog.ModalityType.APPLICATION_MODAL);
        dialog.setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(20, 24, 12, 24));
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(6, 6, 6, 6);
        gc.fill = GridBagConstraints.HORIZONTAL;

        JTextField txtName = new JTextField(!isNew ? existing.getName() : "", 18);
        JComboBox<String> cbUnit = new JComboBox<>(new String[]{"pcs", "meters", "rolls", "kg", "liters", "box", "set"});
        JSpinner spQuantity = new JSpinner(new SpinnerNumberModel(!isNew ? existing.getQuantity() : 0, 0, 100000, 1));
        JComboBox<String> cbType = new JComboBox<>(new String[]{"Piping", "Wiring", "Insulation", "Fastener", "Refrigerant", "Other"});
        JComboBox<String> cbAcType = new JComboBox<>(new String[]{"Any", "Inverter", "Non-Inverter", "Split Type", "Window Type", "Portable"});
        JTextField txtBarcode = new JTextField(!isNew && existing.getBarcode() != null ? existing.getBarcode() : "", 18);
        if (!isNew) {
            cbUnit.setSelectedItem(existing.getUnitOfMeasure());
            cbType.setSelectedItem(existing.getType());
            cbAcType.setSelectedItem(existing.getAcType());
        }

        for (JComponent c : List.of(txtName, cbUnit, spQuantity, cbType, cbAcType, txtBarcode)) {
            c.setEnabled(canEdit);
        }

        int row = 0;
        row = addFormRow(form, gc, row, "Name", txtName);
        row = addFormRow(form, gc, row, "Unit", cbUnit);
        row = addFormRow(form, gc, row, "Quantity", spQuantity);
        row = addFormRow(form, gc, row, "Type", cbType);
        row = addFormRow(form, gc, row, "AC Type", cbAcType);

        JPanel barcodeRow = new JPanel(new BorderLayout(6, 0));
        JButton genBarcodeBtn = new JButton("Generate");
        genBarcodeBtn.setEnabled(canEdit);
        genBarcodeBtn.addActionListener(e -> txtBarcode.setText("MAT-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase()));
        barcodeRow.add(txtBarcode, BorderLayout.CENTER);
        barcodeRow.add(genBarcodeBtn, BorderLayout.EAST);
        addFormRow(form, gc, row, "Barcode", barcodeRow);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        if (!canEdit) {
            JButton close = new JButton("Close");
            close.addActionListener(e -> dialog.dispose());
            buttons.add(close);
        } else {
            JButton cancel = new JButton("Cancel");
            JButton save = new JButton(isNew ? "Add Material" : "Save Changes");
            cancel.addActionListener(e -> dialog.dispose());
            save.addActionListener(e -> {
                if (txtName.getText().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "Name is required.");
                    return;
                }
                String name = txtName.getText().trim();
                String unit = (String) cbUnit.getSelectedItem();
                int qty = (Integer) spQuantity.getValue();
                String type = (String) cbType.getSelectedItem();
                String acType = (String) cbAcType.getSelectedItem();
                String barcode = txtBarcode.getText().trim();
                String barcodeOrNull = barcode.isEmpty() ? null : barcode;

                runAsync(() -> {
                    if (isNew) {
                        dao.insertMaterial(name, unit, qty, type, acType, barcodeOrNull);
                        activityLog.log(Session.getUsername(), "ADD_MATERIAL", "Added material " + name + " (qty " + qty + ")");
                    } else {
                        dao.updateMaterial(existing.getId(), name, unit, qty, type, acType, barcodeOrNull);
                        activityLog.log(Session.getUsername(), "UPDATE_MATERIAL", "Updated material " + name);
                    }
                }, () -> {
                    dialog.dispose();
                    loadMaterials();
                });
            });
            buttons.add(cancel);
            buttons.add(save);
            dialog.getRootPane().setDefaultButton(save);
        }

        dialog.add(form, BorderLayout.CENTER);
        dialog.add(buttons, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void deleteMaterial() {
        Material m = selectedMaterial();
        if (m == null) return;
        if (JOptionPane.showConfirmDialog(this, "Delete " + m.getName() + "?",
                "Confirm", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        runAsync(() -> {
            dao.deleteMaterial(m.getId());
            activityLog.log(Session.getUsername(), "DELETE_MATERIAL", "Deleted material " + m.getName());
        }, this::loadMaterials);
    }

    private void loadMaterials() {
        String keyword = matSearch.getText().trim();
        String unit = (String) matUnitFilter.getSelectedItem();
        String type = (String) matTypeFilter.getSelectedItem();
        String acType = (String) matAcTypeFilter.getSelectedItem();

        new SwingWorker<List<Material>, Void>() {
            SQLException failure;
            @Override protected List<Material> doInBackground() {
                try { return dao.filterMaterials(keyword, unit, type, acType); } catch (SQLException e) { failure = e; return List.of(); }
            }
            @Override protected void done() {
                if (failure != null) { showDbError(failure); return; }
                matModel.setRowCount(0);
                try {
                    for (Material m : get()) {
                        matModel.addRow(new Object[]{m.getId(), m.getName(), m.getUnitOfMeasure(),
                                m.getQuantity(), m.getType(), m.getAcType(),
                                DateTimeUtil.formatDateTime(m.getDateArrived()), m.getBarcode()});
                    }
                } catch (Exception ignored) { }
                if (editable) matDeleteBtn.setEnabled(false);
            }
        }.execute();
    }

    // ================= shared helpers =================

    public void refresh() {
        loadAcUnits();
        loadMaterials();
    }

    private int addFormRow(JPanel form, GridBagConstraints gc, int row, String label, JComponent field) {
        gc.gridx = 0;
        gc.gridy = row;
        gc.weightx = 0;
        JLabel l = new JLabel(label);
        l.setFont(Theme.FONT_LABEL);
        form.add(l, gc);

        gc.gridx = 1;
        gc.weightx = 1;
        form.add(field, gc);
        return row + 1;
    }

    private interface DbAction { void run() throws SQLException; }

    private void runAsync(DbAction action, Runnable onSuccess) {
        new SwingWorker<Void, Void>() {
            SQLException failure;
            @Override protected Void doInBackground() {
                try { action.run(); } catch (SQLException e) { failure = e; }
                return null;
            }
            @Override protected void done() {
                if (failure != null) { showDbError(failure); return; }
                onSuccess.run();
            }
        }.execute();
    }

    private void showDbError(SQLException e) {
        JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
