package com.khierkian.ui;

import com.khierkian.dao.ActivityLogDAO;
import com.khierkian.dao.InventoryDAO;
import com.khierkian.dao.LoginHistoryDAO;
import com.khierkian.model.ActivityLogEntry;
import com.khierkian.model.AirConditioningUnit;
import com.khierkian.model.LoginRecord;
import com.khierkian.model.Material;
import com.khierkian.ui.components.DateTimeUtil;
import com.khierkian.ui.components.DocxExportUtil;
import com.khierkian.ui.components.TableStyler;
import com.khierkian.ui.components.Theme;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Read-only, aggregate view for Administrators — covers AC Units, Materials,
 * Login History, and Activity Log in one place, and exports all four into a
 * single Word document with real tables, marked as final so it opens read-only.
 */
public class ReportPanel extends JPanel {

    private final InventoryDAO inventoryDao = new InventoryDAO();
    private final LoginHistoryDAO loginHistoryDao = new LoginHistoryDAO();
    private final ActivityLogDAO activityLogDao = new ActivityLogDAO();

    private final JLabel acSummary = new JLabel();
    private final DefaultTableModel acModel = new DefaultTableModel(
            new String[]{"Brand", "Model No.", "Type", "Qty", "Status", "Arrived"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable acTable = new JTable(acModel);

    private final JLabel matSummary = new JLabel();
    private final DefaultTableModel matModel = new DefaultTableModel(
            new String[]{"Name", "Unit", "Qty", "Type", "AC Type", "Arrived"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable matTable = new JTable(matModel);

    private final DefaultTableModel loginModel = new DefaultTableModel(
            new String[]{"Last Name", "First Name", "Role", "Date", "Time", "Status", "IP Address"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable loginTable = new JTable(loginModel);

    private final DefaultTableModel activityModel = new DefaultTableModel(
            new String[]{"Staff", "Action", "Details", "Date", "Time"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable activityTable = new JTable(activityModel);

    private final JComboBox<String> periodCombo = new JComboBox<>(
            new String[]{"All Time", "Today", "This Week", "This Month", "This Year"});

    public ReportPanel() {
        setLayout(new BorderLayout());
        setBackground(Theme.CONTENT_BG);
        setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));

        JLabel heading = new JLabel("Report");
        heading.setFont(Theme.FONT_TITLE);
        heading.setForeground(Theme.TEXT_ON_LIGHT);

        JLabel periodLabel = new JLabel("Period:");
        periodLabel.setForeground(Theme.TEXT_MUTED_ON_LIGHT);
        periodLabel.setFont(Theme.FONT_LABEL);
        periodCombo.addActionListener(e -> refresh());

        JButton exportBtn = new JButton("Export Full Report to Word");
        exportBtn.addActionListener(e -> exportToDocx());

        JPanel rightControls = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        rightControls.setOpaque(false);
        rightControls.add(periodLabel);
        rightControls.add(periodCombo);
        rightControls.add(exportBtn);

        JPanel headerRow = new JPanel(new BorderLayout());
        headerRow.setOpaque(false);
        headerRow.setBorder(BorderFactory.createEmptyBorder(0, 0, 16, 0));
        headerRow.add(heading, BorderLayout.WEST);
        headerRow.add(rightControls, BorderLayout.EAST);
        add(headerRow, BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("AC Units", buildTab(acSummary, acTable, 110, 110, 100, 50, 100, 170));
        tabs.addTab("Materials", buildTab(matSummary, matTable, 150, 80, 60, 110, 110, 170));
        tabs.addTab("Login History", buildTab(null, loginTable, 100, 100, 110, 110, 100, 90, 120));
        tabs.addTab("Activity Log", buildTab(null, activityTable, 100, 100, 220, 110, 100));
        add(tabs, BorderLayout.CENTER);
    }

    /** Maps the period dropdown to a day count for the DAOs — null means no date restriction. */
    private Integer selectedPeriodDays() {
        return switch (periodCombo.getSelectedIndex()) {
            case 1 -> 1;    // Today
            case 2 -> 7;    // This Week
            case 3 -> 30;   // This Month
            case 4 -> 365;  // This Year
            default -> null; // All Time
        };
    }

    private String selectedPeriodLabel() {
        return (String) periodCombo.getSelectedItem();
    }

    private JComponent buildTab(JLabel summaryOrNull, JTable table, int... columnWidths) {
        JPanel panel = new JPanel(new BorderLayout(0, 8));
        panel.setOpaque(false);
        if (summaryOrNull != null) {
            summaryOrNull.setFont(Theme.FONT_LABEL);
            summaryOrNull.setForeground(Theme.TEXT_ON_LIGHT);
            panel.add(summaryOrNull, BorderLayout.NORTH);
        }
        TableStyler.style(table);
        TableStyler.setColumnWidths(table, columnWidths);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    public void refresh() {
        Integer days = selectedPeriodDays();

        new SwingWorker<List<AirConditioningUnit>, Void>() {
            SQLException failure;
            @Override protected List<AirConditioningUnit> doInBackground() {
                try { return inventoryDao.filterUnits(null, null, null, days); } catch (SQLException e) { failure = e; return List.of(); }
            }
            @Override protected void done() {
                if (failure != null) { showError(failure); return; }
                try {
                    List<AirConditioningUnit> units = get();
                    acModel.setRowCount(0);
                    int totalQty = 0, outOfStock = 0;
                    for (AirConditioningUnit u : units) {
                        acModel.addRow(new Object[]{u.getBrand(), u.getModelNo(), u.getType(), u.getQuantity(),
                                u.getStatus(), DateTimeUtil.formatDateTime(u.getDateArrived())});
                        totalQty += u.getQuantity();
                        if ("Out of Stock".equalsIgnoreCase(u.getStatus())) outOfStock++;
                    }
                    acSummary.setText(units.size() + " AC models  •  " + totalQty + " total units in stock  •  "
                            + outOfStock + " out of stock");
                } catch (Exception ignored) { }
            }
        }.execute();

        new SwingWorker<List<Material>, Void>() {
            SQLException failure;
            @Override protected List<Material> doInBackground() {
                try { return inventoryDao.filterMaterials(null, null, null, null, days); } catch (SQLException e) { failure = e; return List.of(); }
            }
            @Override protected void done() {
                if (failure != null) { showError(failure); return; }
                try {
                    List<Material> materials = get();
                    matModel.setRowCount(0);
                    int totalQty = 0;
                    for (Material m : materials) {
                        matModel.addRow(new Object[]{m.getName(), m.getUnitOfMeasure(), m.getQuantity(), m.getType(),
                                m.getAcType(), DateTimeUtil.formatDateTime(m.getDateArrived())});
                        totalQty += m.getQuantity();
                    }
                    matSummary.setText(materials.size() + " material types  •  " + totalQty + " total quantity");
                } catch (Exception ignored) { }
            }
        }.execute();

        new SwingWorker<List<LoginRecord>, Void>() {
            SQLException failure;
            @Override protected List<LoginRecord> doInBackground() {
                try { return loginHistoryDao.findAll(LoginHistoryDAO.Filter.ALL, days); }
                catch (SQLException e) { failure = e; return List.of(); }
            }
            @Override protected void done() {
                if (failure != null) { showError(failure); return; }
                try {
                    loginModel.setRowCount(0);
                    for (LoginRecord r : get()) {
                        loginModel.addRow(new Object[]{r.getLastName(), r.getFirstName(), r.getRole(),
                                DateTimeUtil.formatDate(r.getLoginTime()), DateTimeUtil.formatTime(r.getLoginTime()),
                                r.getStatus(), r.getIpAddress()});
                    }
                } catch (Exception ignored) { }
            }
        }.execute();

        new SwingWorker<List<ActivityLogEntry>, Void>() {
            SQLException failure;
            @Override protected List<ActivityLogEntry> doInBackground() {
                try { return activityLogDao.findAll(days); } catch (SQLException e) { failure = e; return List.of(); }
            }
            @Override protected void done() {
                if (failure != null) { showError(failure); return; }
                try {
                    activityModel.setRowCount(0);
                    for (ActivityLogEntry entry : get()) {
                        activityModel.addRow(new Object[]{entry.getUsername(), entry.getAction(), entry.getDescription(),
                                DateTimeUtil.formatDate(entry.getActionTime()), DateTimeUtil.formatTime(entry.getActionTime())});
                    }
                } catch (Exception ignored) { }
            }
        }.execute();
    }

    private void showError(SQLException e) {
        JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    // ================= Word export =================

    private void exportToDocx() {
        JFileChooser chooser = new JFileChooser();
        String periodSlug = selectedPeriodLabel().replace(" ", "");
        String defaultName = "KhierKian_Report_" + periodSlug + "_"
                + new SimpleDateFormat("yyyyMMdd_HHmm").format(new Date()) + ".docx";
        chooser.setSelectedFile(new File(defaultName));
        chooser.setDialogTitle("Save Report As");
        int result = chooser.showSaveDialog(this);
        if (result != JFileChooser.APPROVE_OPTION) {
            return;
        }

        File file = chooser.getSelectedFile();
        if (!file.getName().toLowerCase().endsWith(".docx")) {
            file = new File(file.getParentFile(), file.getName() + ".docx");
        }
        final File targetFile = file;
        final String periodLabel = selectedPeriodLabel();

        new SwingWorker<Void, Void>() {
            Exception failure;
            @Override protected Void doInBackground() {
                try {
                    String generatedLine = "Period: " + periodLabel + "  •  Generated "
                            + DateTimeUtil.formatDateTime(new java.sql.Timestamp(System.currentTimeMillis())) + " (GMT+8)";
                    List<DocxExportUtil.Section> sections = new ArrayList<>();
                    sections.add(new DocxExportUtil.Section("AC Units — " + plainText(acSummary), columnNames(acModel), rowsOf(acModel)));
                    sections.add(new DocxExportUtil.Section("Materials — " + plainText(matSummary), columnNames(matModel), rowsOf(matModel)));
                    sections.add(new DocxExportUtil.Section("Login History", columnNames(loginModel), rowsOf(loginModel)));
                    sections.add(new DocxExportUtil.Section("Activity Log", columnNames(activityModel), rowsOf(activityModel)));

                    DocxExportUtil.export(targetFile, "KhierKian Air-Conditioning Services — " + periodLabel + " Report",
                            generatedLine, sections);
                } catch (IOException e) {
                    failure = e;
                }
                return null;
            }

            @Override protected void done() {
                if (failure != null) {
                    JOptionPane.showMessageDialog(ReportPanel.this,
                            "Could not export: " + failure.getMessage(), "Export Failed", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                JOptionPane.showMessageDialog(ReportPanel.this,
                        "Report saved to:\n" + targetFile.getAbsolutePath()
                                + "\n\nIt's marked as Final, so Word will open it read-only by default.",
                        "Export Complete", JOptionPane.INFORMATION_MESSAGE);
            }
        }.execute();
    }

    /** Strips the "•" separators used on-screen — kept plain for the Word doc. */
    private String plainText(JLabel label) {
        String text = label.getText();
        return text == null ? "" : text.replace("•", "-");
    }

    private String[] columnNames(DefaultTableModel model) {
        String[] names = new String[model.getColumnCount()];
        for (int i = 0; i < names.length; i++) {
            names[i] = model.getColumnName(i);
        }
        return names;
    }

    private List<String[]> rowsOf(DefaultTableModel model) {
        List<String[]> rows = new ArrayList<>();
        for (int r = 0; r < model.getRowCount(); r++) {
            String[] row = new String[model.getColumnCount()];
            for (int c = 0; c < row.length; c++) {
                Object value = model.getValueAt(r, c);
                row[c] = value == null ? "" : value.toString();
            }
            rows.add(row);
        }
        return rows;
    }
}
