package com.khierkian.ui.components;

import javax.swing.*;
import java.awt.*;

/** A JPanel with rounded corners and an optional soft border glow — used for the login card. */
public class RoundedPanel extends JPanel {

    private final int arc;
    private final Color fill;
    private final Color borderColor;

    public RoundedPanel(int arc, Color fill, Color borderColor) {
        this.arc = arc;
        this.fill = fill;
        this.borderColor = borderColor;
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();

        // Soft outer glow: a few translucent rounded rects, each slightly bigger than the last.
        if (borderColor != null) {
            for (int i = 6; i >= 1; i--) {
                g2.setColor(new Color(borderColor.getRed(), borderColor.getGreen(), borderColor.getBlue(), 10));
                g2.fillRoundRect(i, i, w - 2 * i, h - 2 * i, arc + i, arc + i);
            }
        }

        g2.setColor(fill);
        g2.fillRoundRect(0, 0, w - 1, h - 1, arc, arc);

        if (borderColor != null) {
            g2.setColor(borderColor);
            g2.setStroke(new BasicStroke(1.4f));
            g2.drawRoundRect(0, 0, w - 1, h - 1, arc, arc);
        }

        g2.dispose();
        super.paintComponent(g);
    }
}
