package com.khierkian.ui;

import com.khierkian.scanner.QrCodeUtil;
import com.khierkian.scanner.ScannerServer;
import com.khierkian.ui.components.Theme;

import javax.swing.*;
import java.awt.*;

/**
 * Lets a Technical Staff user start the local scanner server and shows a QR
 * code that opens the mobile scan page directly on their phone — no typing
 * an IP address.
 */
public class ScannerPanel extends JPanel {

    private static final int PORT = 8181;

    private final ScannerServer server = new ScannerServer();

    private final JLabel statusLabel = new JLabel();
    private final JLabel urlLabel = new JLabel();
    private final JLabel qrImageLabel = new JLabel();
    private final JButton toggleBtn = new JButton();

    public ScannerPanel() {
        setLayout(new BorderLayout());
        setBackground(Theme.CONTENT_BG);
        setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));

        JLabel heading = new JLabel("Scanner");
        heading.setFont(Theme.FONT_TITLE);
        heading.setForeground(Theme.TEXT_ON_LIGHT);
        heading.setBorder(BorderFactory.createEmptyBorder(0, 0, 16, 0));
        add(heading, BorderLayout.NORTH);

        JPanel center = new JPanel();
        center.setOpaque(false);
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));

        JLabel instructions = new JLabel("<html><body style='width:420px'>"
                + "Start the scanner, then open the link below on your phone's browser — or scan the QR code with "
                + "your phone's camera app. Your phone and this computer must be on the same WiFi network. "
                + "Log in with a Technical Staff account to scan AC units or materials and update stock instantly."
                + "</body></html>");
        instructions.setFont(Theme.FONT_BODY);
        instructions.setForeground(Theme.TEXT_MUTED_ON_LIGHT);
        instructions.setAlignmentX(Component.LEFT_ALIGNMENT);
        center.add(instructions);
        center.add(Box.createVerticalStrut(20));

        statusLabel.setFont(Theme.FONT_HEADING);
        statusLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        center.add(statusLabel);
        center.add(Box.createVerticalStrut(6));

        urlLabel.setFont(Theme.FONT_LABEL);
        urlLabel.setForeground(Theme.LINK_ON_LIGHT);
        urlLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        center.add(urlLabel);
        center.add(Box.createVerticalStrut(16));

        toggleBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        toggleBtn.setMaximumSize(new Dimension(220, 40));
        toggleBtn.addActionListener(e -> toggleServer());
        center.add(toggleBtn);
        center.add(Box.createVerticalStrut(20));

        qrImageLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        qrImageLabel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        qrImageLabel.setOpaque(true);
        qrImageLabel.setBackground(Color.WHITE);
        center.add(qrImageLabel);

        add(center, BorderLayout.CENTER);
        refreshStatus();
    }

    public void refresh() {
        refreshStatus();
    }

    /** Stops the server if it's running — called on logout so the port is freed. */
    public void shutdown() {
        if (server.isRunning()) {
            server.stop();
        }
    }

    private void toggleServer() {
        if (server.isRunning()) {
            server.stop();
        } else {
            try {
                server.start(PORT);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                        "Could not start the scanner server: " + e.getMessage()
                                + "\n\nIf this mentions scanner-keystore.jks, you need to generate it once first — see README \"Scanner HTTPS setup\". "
                                + "Otherwise, another program might already be using port " + PORT + ".",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        refreshStatus();
    }

    private void refreshStatus() {
        if (server.isRunning()) {
            String url = "https://" + server.getLocalIp() + ":" + server.getPort() + "/";
            statusLabel.setForeground(Theme.SUCCESS_ON_LIGHT);
            statusLabel.setText("Scanner is running");
            urlLabel.setText(url);
            toggleBtn.setText("Stop Scanner");
            ImageIcon qr = QrCodeUtil.generateIcon(url, 220);
            qrImageLabel.setIcon(qr);
            qrImageLabel.setVisible(true);
        } else {
            statusLabel.setForeground(Theme.TEXT_MUTED_ON_LIGHT);
            statusLabel.setText("Scanner is stopped");
            urlLabel.setText(" ");
            toggleBtn.setText("Start Scanner");
            qrImageLabel.setIcon(null);
            qrImageLabel.setVisible(false);
        }
    }
}
