package com.khierkian.ui.components;

import java.awt.Color;
import java.awt.Font;

/** Central place for the app's palette/typography so every screen looks consistent. */
public final class Theme {
    private Theme() {}

    public static final Color NAVY_DARK   = new Color(2, 17, 37);
    public static final Color NAVY        = new Color(26, 47, 97);
    public static final Color ACCENT      = new Color(64, 132, 214);
    public static final Color SUCCESS     = new Color(102, 187, 106);
    public static final Color WARNING     = new Color(255, 183, 77);
    public static final Color DANGER      = new Color(239, 83, 80);
    public static final Color CARD_BG     = new Color(38, 50, 82);
    public static final Color TEXT_LIGHT  = new Color(235, 238, 245);
    public static final Color TEXT_MUTED  = new Color(160, 168, 192);

    public static final Font FONT_TITLE     = new Font("Segoe UI", Font.BOLD, 26);
    public static final Font FONT_HEADING   = new Font("Segoe UI", Font.BOLD, 16);
    public static final Font FONT_LABEL     = new Font("Segoe UI", Font.BOLD, 13);
    public static final Font FONT_BODY      = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_STAT      = new Font("Segoe UI", Font.BOLD, 34);
    public static final Font FONT_CARD_TITLE = new Font("Segoe UI", Font.BOLD, 16);

    // Table styling — light blue background per user request, dark text for contrast.
    public static final Color TABLE_BG        = new Color(214, 234, 248);
    public static final Color TABLE_BG_ALT    = new Color(230, 243, 252);
    public static final Color TABLE_TEXT      = new Color(18, 32, 51);
    public static final Color TABLE_HEADER_BG = new Color(132, 184, 228);
    public static final Color TABLE_SELECTION = new Color(144, 202, 249);

    // Sidebar nav highlight
    public static final Color NAV_ACTIVE_BG   = ACCENT;

    // ---- Light main-screen background (the area next to the dark sidebar) ----
    public static final Color CONTENT_BG          = new Color(168, 216, 245);
    public static final Color CONTENT_BG_SOFT     = new Color(194, 230, 251);
    public static final Color TEXT_ON_LIGHT       = new Color(10, 28, 58);
    public static final Color TEXT_MUTED_ON_LIGHT = new Color(44, 68, 108);
    public static final Color SUCCESS_ON_LIGHT    = new Color(22, 118, 58);
    public static final Color LINK_ON_LIGHT       = new Color(14, 74, 146);
}
