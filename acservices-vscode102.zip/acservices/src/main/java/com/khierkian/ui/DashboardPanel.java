package com.khierkian.ui;

import com.khierkian.dao.DashboardDAO;
import com.khierkian.session.Session;
import com.khierkian.ui.components.StatCard;
import com.khierkian.ui.components.Theme;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

public class DashboardPanel extends JPanel {

    private final DashboardDAO dao = new DashboardDAO();

    private final JLabel welcomeLabel = new JLabel();
    private final StatCard totalAcCard = new StatCard("Total AC Units");
    private final StatCard outOfStockCard = new StatCard("Out of Stock");
    private final StatCard materialsCard = new StatCard("Total Materials");
    private final StatCard lowStockCard = new StatCard("Low Stock");
    private final StatCard topSellingCard = new StatCard("Top Selling Models");
    private final StatCard reorderCard = new StatCard("Re-order Monitor");

    public DashboardPanel() {
        setLayout(new BorderLayout());
        setBackground(Theme.CONTENT_BG);
        setBorder(BorderFactory.createEmptyBorder(28, 32, 28, 32));

        welcomeLabel.setFont(Theme.FONT_TITLE);
        welcomeLabel.setForeground(Theme.TEXT_ON_LIGHT);
        add(welcomeLabel, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(2, 3, 18, 18));
        grid.setOpaque(false);
        grid.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
        grid.add(totalAcCard);
        grid.add(outOfStockCard);
        grid.add(materialsCard);
        grid.add(lowStockCard);
        grid.add(topSellingCard);
        grid.add(reorderCard);

        add(grid, BorderLayout.CENTER);
    }

    public void refresh() {
        welcomeLabel.setText("Welcome back, " + Session.getFirstName());

        new SwingWorker<Void, Void>() {
            int totalAc, totalMaterials;
            List<String> outOfStock, recentMaterials, topSelling;
            List<DashboardDAO.NameQty> lowStock, reorder;
            SQLException failure;

            @Override
            protected Void doInBackground() {
                try {
                    totalAc = dao.totalAcUnits();
                    outOfStock = dao.outOfStock(3);
                    totalMaterials = dao.totalMaterials();
                    recentMaterials = dao.recentMaterialNames(3);
                    lowStock = dao.lowStock(3);
                    topSelling = dao.topSelling(3);
                    reorder = dao.reorderMonitor(3);
                } catch (SQLException e) {
                    failure = e;
                }
                return null;
            }

            @Override
            protected void done() {
                if (failure != null) {
                    totalAcCard.setStatValue("--");
                    outOfStockCard.setLines(List.of(), "Couldn't load data", Theme.DANGER);
                    return;
                }
                totalAcCard.setStatValue(String.format("%,d", totalAc));
                outOfStockCard.setLines(outOfStock, "All items in stock", Theme.SUCCESS);
                materialsCard.setStatWithLines(String.format("%,d", totalMaterials), recentMaterials);
                lowStockCard.setLines(
                        lowStock.stream().map(nq -> nq.name() + " — " + nq.quantity()).collect(Collectors.toList()),
                        "Stock levels healthy", Theme.SUCCESS);
                topSellingCard.setLines(topSelling, "No data yet", Theme.TEXT_MUTED);
                reorderCard.setLines(
                        reorder.stream().map(nq -> nq.name() + " — " + nq.quantity()).collect(Collectors.toList()),
                        "Nothing to reorder", Theme.SUCCESS);
            }
        }.execute();
    }
}
