package com.khierkian.ui;

import com.khierkian.dao.UserDAO;
import com.khierkian.session.Session;
import com.khierkian.ui.components.IconUtil;
import com.khierkian.ui.components.Theme;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

public class MainFrame extends JFrame {

    private static final String CARD_DASHBOARD = "dashboard";
    private static final String CARD_INVENTORY = "inventory";
    private static final String CARD_USERS = "users";
    private static final String CARD_LOGIN_HISTORY = "login_history";
    private static final String CARD_ACTIVITY_LOG = "activity_log";
    private static final String CARD_REPORT = "report";
    private static final String CARD_SCANNER = "scanner";

    private final UserDAO userDAO = new UserDAO();

    private final CardLayout cardLayout = new CardLayout();
    private final JPanel cardHost = new JPanel(cardLayout);
    private final Map<String, JButton> navButtons = new LinkedHashMap<>();

    private final DashboardPanel dashboardPanel = new DashboardPanel();
    private final InventoryPanel inventoryPanel = new InventoryPanel();
    private final UserManagementPanel userManagementPanel = new UserManagementPanel();
    private final LoginHistoryPanel loginHistoryPanel = new LoginHistoryPanel();
    private final ActivityLogPanel activityLogPanel = new ActivityLogPanel();
    private final ReportPanel reportPanel = new ReportPanel();
    private final ScannerPanel scannerPanel = new ScannerPanel();

    private JPanel historySubMenu;
    private boolean historyExpanded = false;

    public MainFrame() {
        setTitle("KhierKian Air-Conditioning Services");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new BorderLayout());
        add(buildSidebar(), BorderLayout.WEST);
        cardHost.setBackground(Theme.CONTENT_BG);
        add(cardHost, BorderLayout.CENTER);

        cardHost.add(dashboardPanel, CARD_DASHBOARD);
        cardHost.add(inventoryPanel, CARD_INVENTORY);
        cardHost.add(userManagementPanel, CARD_USERS);
        cardHost.add(loginHistoryPanel, CARD_LOGIN_HISTORY);
        cardHost.add(activityLogPanel, CARD_ACTIVITY_LOG);
        cardHost.add(reportPanel, CARD_REPORT);
        cardHost.add(scannerPanel, CARD_SCANNER);

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setMinimumSize(new Dimension(1100, 700));

        showCard(CARD_DASHBOARD);
    }

    private JComponent buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(Theme.NAVY_DARK);
        sidebar.setBorder(BorderFactory.createEmptyBorder(24, 16, 24, 16));
        sidebar.setPreferredSize(new Dimension(230, 0));

        JLabel brand = new JLabel("<html>KhierKian AC<br>Services</html>");
        brand.setFont(Theme.FONT_HEADING);
        brand.setForeground(Theme.TEXT_LIGHT);

        ImageIcon logoIcon = IconUtil.loadIcon("/images/logo.png", 36, 34);
        JPanel brandRow = new JPanel();
        brandRow.setLayout(new BoxLayout(brandRow, BoxLayout.X_AXIS));
        brandRow.setOpaque(false);
        brandRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        if (logoIcon != null) {
            JLabel logoLabel = new JLabel(logoIcon);
            brandRow.add(logoLabel);
            brandRow.add(Box.createHorizontalStrut(8));
        }
        brandRow.add(brand);
        sidebar.add(brandRow);

        sidebar.add(Box.createVerticalStrut(4));
        addUserInfoChip(sidebar);
        sidebar.add(Box.createVerticalStrut(28));

        addNavButton(sidebar, "Dashboard", CARD_DASHBOARD, true);
        addNavButton(sidebar, "Inventory", CARD_INVENTORY, true);
        addNavButton(sidebar, "Scanner", CARD_SCANNER, !Session.isAdmin());
        addNavButton(sidebar, "User Management", CARD_USERS, Session.isAdmin());
        addNavButton(sidebar, "Report", CARD_REPORT, Session.isAdmin());

        if (Session.isAdmin()) {
            addHistoryMenu(sidebar);
        }

        sidebar.add(Box.createVerticalGlue());

        return sidebar;
    }

    /**
     * A clickable name/role chip in the sidebar. Clicking it opens a small
     * popup beside it where the user can edit their own name/phone and log out.
     */
    private void addUserInfoChip(JPanel sidebar) {
        JPanel chip = new JPanel();
        chip.setLayout(new BoxLayout(chip, BoxLayout.Y_AXIS));
        chip.setOpaque(false);
        chip.setAlignmentX(Component.LEFT_ALIGNMENT);
        chip.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        chip.setBorder(BorderFactory.createEmptyBorder(4, 2, 4, 2));
        chip.setToolTipText("Click to edit your info or log out");

        JLabel who = new JLabel(Session.getFullName().trim());
        who.setFont(Theme.FONT_BODY);
        who.setForeground(Theme.TEXT_MUTED);
        who.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel role = new JLabel(Session.getRole());
        role.setIcon(new ChevronIcon(false, Theme.ACCENT));
        role.setHorizontalTextPosition(SwingConstants.LEADING);
        role.setIconTextGap(8);
        role.setFont(Theme.FONT_BODY);
        role.setForeground(Theme.ACCENT);
        role.setAlignmentX(Component.LEFT_ALIGNMENT);

        chip.add(who);
        chip.add(role);

        JPopupMenu popup = buildUserPopup(who);
        chip.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                popup.show(chip, chip.getWidth() + 8, 0);
            }
        });

        sidebar.add(chip);
    }

    /** The little panel that appears beside the user chip: editable name/phone, read-only role, and Log Out. */
    private JPopupMenu buildUserPopup(JLabel chipNameLabel) {
        JPopupMenu popup = new JPopupMenu();
        popup.setBorder(BorderFactory.createLineBorder(Theme.ACCENT, 1));

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBackground(Theme.NAVY);
        content.setBorder(BorderFactory.createEmptyBorder(14, 16, 14, 16));

        JTextField txtFirstName = new JTextField(Session.getFirstName(), 14);
        JTextField txtLastName = new JTextField(Session.getLastName(), 14);
        JTextField txtPhone = new JTextField(Session.getPhone() != null ? Session.getPhone() : "", 14);
        JLabel roleValue = new JLabel(Session.getRole());
        roleValue.setFont(Theme.FONT_LABEL);
        roleValue.setForeground(Theme.ACCENT);
        roleValue.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel statusLabel = new JLabel(" ");
        statusLabel.setFont(Theme.FONT_BODY);
        statusLabel.setForeground(Theme.DANGER);
        statusLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton saveBtn = new JButton("Save");
        saveBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        saveBtn.setMaximumSize(new Dimension(200, 34));
        saveBtn.addActionListener(e -> {
            String firstName = txtFirstName.getText().trim();
            String lastName = txtLastName.getText().trim();
            String phone = txtPhone.getText().trim();
            if (firstName.isEmpty() || lastName.isEmpty()) {
                statusLabel.setText("Name can't be empty.");
                return;
            }
            int id = Session.getUserId();
            new SwingWorker<Void, Void>() {
                SQLException failure;
                @Override protected Void doInBackground() {
                    try { userDAO.updateOwnProfile(id, firstName, lastName, phone); }
                    catch (SQLException ex) { failure = ex; }
                    return null;
                }
                @Override protected void done() {
                    if (failure != null) {
                        statusLabel.setText("Could not save.");
                        return;
                    }
                    Session.updateProfile(firstName, lastName, phone);
                    chipNameLabel.setText(Session.getFullName().trim());
                    popup.setVisible(false);
                }
            }.execute();
        });

        JButton logoutBtn = new JButton("Log Out");
        logoutBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        logoutBtn.setMaximumSize(new Dimension(200, 34));
        logoutBtn.addActionListener(e -> {
            popup.setVisible(false);
            onLogout();
        });

        content.add(popupFieldLabel("First Name"));
        content.add(sizedField(txtFirstName));
        content.add(Box.createVerticalStrut(8));
        content.add(popupFieldLabel("Last Name"));
        content.add(sizedField(txtLastName));
        content.add(Box.createVerticalStrut(8));
        content.add(popupFieldLabel("Phone Number"));
        content.add(sizedField(txtPhone));
        content.add(Box.createVerticalStrut(8));
        content.add(popupFieldLabel("Role"));
        content.add(roleValue);
        content.add(Box.createVerticalStrut(4));
        content.add(statusLabel);
        content.add(Box.createVerticalStrut(10));
        content.add(saveBtn);
        content.add(Box.createVerticalStrut(6));
        content.add(logoutBtn);

        popup.add(content);
        return popup;
    }

    private JLabel popupFieldLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(Theme.FONT_BODY);
        l.setForeground(Theme.TEXT_MUTED);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        return l;
    }

    private JComponent sizedField(JTextField field) {
        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        field.setMaximumSize(new Dimension(200, 30));
        return field;
    }

    /** "History" toggles a small indented submenu with Login History and Activity Log. */
    private void addHistoryMenu(JPanel sidebar) {
        JButton historyToggle = new JButton("History");
        historyToggle.setIcon(new ChevronIcon(false, Theme.TEXT_MUTED));
        historyToggle.setHorizontalTextPosition(SwingConstants.LEADING);
        historyToggle.setIconTextGap(10);
        historyToggle.setAlignmentX(Component.LEFT_ALIGNMENT);
        historyToggle.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        historyToggle.setHorizontalAlignment(SwingConstants.LEFT);
        historyToggle.setFocusPainted(false);
        historyToggle.setOpaque(true);
        historyToggle.setBorderPainted(false);
        historyToggle.setContentAreaFilled(true);
        historyToggle.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        historyToggle.setBackground(Theme.NAVY_DARK);
        historyToggle.setForeground(Theme.TEXT_MUTED);
        historyToggle.setFont(Theme.FONT_BODY);

        historySubMenu = new JPanel();
        historySubMenu.setLayout(new BoxLayout(historySubMenu, BoxLayout.Y_AXIS));
        historySubMenu.setOpaque(false);
        historySubMenu.setAlignmentX(Component.LEFT_ALIGNMENT);
        historySubMenu.setVisible(false);

        addSubNavButton(historySubMenu, "Login History", CARD_LOGIN_HISTORY);
        addSubNavButton(historySubMenu, "Activity Log", CARD_ACTIVITY_LOG);

        historyToggle.addActionListener(e -> {
            historyExpanded = !historyExpanded;
            historySubMenu.setVisible(historyExpanded);
            historyToggle.setIcon(new ChevronIcon(historyExpanded, Theme.TEXT_MUTED));
            sidebar.revalidate();
        });

        sidebar.add(Box.createVerticalStrut(4));
        sidebar.add(historyToggle);
        sidebar.add(historySubMenu);
    }

    private void addSubNavButton(JPanel parent, String label, String card) {
        JButton btn = new JButton(label);
        btn.setAlignmentX(Component.LEFT_ALIGNMENT);
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(true);
        btn.setBorder(BorderFactory.createEmptyBorder(6, 28, 6, 12));
        applyInactiveStyle(btn);
        btn.addActionListener(e -> showCard(card));
        navButtons.put(card, btn);
        parent.add(Box.createVerticalStrut(2));
        parent.add(btn);
    }

    private void addNavButton(JPanel sidebar, String label, String card, boolean visible) {
        JButton btn = new JButton(label);
        btn.setAlignmentX(Component.LEFT_ALIGNMENT);
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setFocusPainted(false);
        btn.setVisible(visible);
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(true);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        applyInactiveStyle(btn);
        btn.addActionListener(e -> showCard(card));
        navButtons.put(card, btn);
        sidebar.add(Box.createVerticalStrut(4));
        sidebar.add(btn);
    }

    private void applyInactiveStyle(JButton btn) {
        btn.setBackground(Theme.NAVY_DARK);
        btn.setForeground(Theme.TEXT_MUTED);
        btn.setFont(Theme.FONT_BODY);
    }

    private void applyActiveStyle(JButton btn) {
        btn.setBackground(Theme.NAV_ACTIVE_BG);
        btn.setForeground(Color.WHITE);
        btn.setFont(Theme.FONT_LABEL);
    }

    private void showCard(String card) {
        cardLayout.show(cardHost, card);
        navButtons.forEach((key, btn) -> {
            if (key.equals(card)) {
                applyActiveStyle(btn);
            } else {
                applyInactiveStyle(btn);
            }
        });

        switch (card) {
            case CARD_DASHBOARD -> dashboardPanel.refresh();
            case CARD_INVENTORY -> inventoryPanel.refresh();
            case CARD_USERS -> userManagementPanel.refresh();
            case CARD_LOGIN_HISTORY -> loginHistoryPanel.refresh();
            case CARD_ACTIVITY_LOG -> activityLogPanel.refresh();
            case CARD_REPORT -> reportPanel.refresh();
            case CARD_SCANNER -> scannerPanel.refresh();
            default -> {}
        }
    }

    private void onLogout() {
        int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to log out?",
                "Log Out", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (choice == JOptionPane.YES_OPTION) {
            scannerPanel.shutdown();
            Session.clear();
            new LoginFrame().setVisible(true);
            dispose();
        }
    }

    /** A small drawn arrow, so it shows correctly on every PC (font glyphs like the old triangle can render as a box). */
    private static class ChevronIcon implements Icon {
        private final boolean down;
        private final Color color;

        ChevronIcon(boolean down, Color color) {
            this.down = down;
            this.color = color;
        }

        @Override public int getIconWidth() { return 10; }
        @Override public int getIconHeight() { return 10; }

        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.setStroke(new BasicStroke(1.8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            if (down) {
                g2.drawPolyline(new int[]{x + 1, x + 5, x + 9}, new int[]{y + 3, y + 7, y + 3}, 3);
            } else {
                g2.drawPolyline(new int[]{x + 3, x + 7, x + 3}, new int[]{y + 1, y + 5, y + 9}, 3);
            }
            g2.dispose();
        }
    }
}
