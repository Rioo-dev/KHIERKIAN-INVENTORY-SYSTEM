package com.khierkian.ui.components;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

public final class IconUtil {
    private IconUtil() {}

    /** Loads an image from the classpath (src/main/resources/...) and scales it. Returns null (never throws) if missing. */
    public static ImageIcon loadIcon(String classpathResource, int width, int height) {
        URL url = IconUtil.class.getResource(classpathResource);
        if (url == null) {
            System.err.println("Icon not found on classpath: " + classpathResource);
            return null;
        }
        ImageIcon raw = new ImageIcon(url);
        Image scaled = raw.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(scaled);
    }
}
