package com.khierkian.ui.components;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

/**
 * All timestamps in the app are displayed in GMT+8 regardless of the
 * machine's own timezone/locale. Dates are numeric only (MM/dd/yyyy —
 * no "Jan/Feb" style month letters). Times are 12-hour with AM/PM.
 */
public final class DateTimeUtil {
    private DateTimeUtil() {}

    private static final TimeZone GMT_PLUS_8 = TimeZone.getTimeZone("GMT+8");

    public static String formatDate(Timestamp ts) {
        if (ts == null) return "";
        SimpleDateFormat fmt = new SimpleDateFormat("MM/dd/yyyy");
        fmt.setTimeZone(GMT_PLUS_8);
        return fmt.format(ts);
    }

    public static String formatTime(Timestamp ts) {
        if (ts == null) return "";
        SimpleDateFormat fmt = new SimpleDateFormat("hh:mm a");
        fmt.setTimeZone(GMT_PLUS_8);
        return fmt.format(ts);
    }

    public static String formatDateTime(Timestamp ts) {
        if (ts == null) return "";
        SimpleDateFormat fmt = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
        fmt.setTimeZone(GMT_PLUS_8);
        return fmt.format(ts);
    }
}
