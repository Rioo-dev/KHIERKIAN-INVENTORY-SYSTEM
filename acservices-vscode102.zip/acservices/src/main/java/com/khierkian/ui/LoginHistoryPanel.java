package com.khierkian.ui;

import com.khierkian.dao.LoginHistoryDAO;
import com.khierkian.model.LoginRecord;
import com.khierkian.ui.components.DateTimeUtil;
import com.khierkian.ui.components.TableStyler;
import com.khierkian.ui.components.Theme;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class LoginHistoryPanel extends JPanel {

    private final LoginHistoryDAO dao = new LoginHistoryDAO();

    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"Last Name", "First Name", "Role", "Date", "Time", "Status", "IP Address"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JComboBox<String> filterCombo = new JComboBox<>(new String[]{"All Logs", "Success Only", "Failed Only"});

    public LoginHistoryPanel() {
        setLayout(new BorderLayout());
        setBackground(Theme.CONTENT_BG);
        setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));

        JLabel heading = new JLabel("Login History");
        heading.setFont(Theme.FONT_TITLE);
        heading.setForeground(Theme.TEXT_ON_LIGHT);
        add(heading, BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(0, 12));
        center.setOpaque(false);
        center.setBorder(BorderFactory.createEmptyBorder(16, 0, 0, 0));

        JPanel filterRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        filterRow.setOpaque(false);
        JLabel filterLabel = new JLabel("Filter:");
        filterLabel.setForeground(Theme.TEXT_MUTED_ON_LIGHT);
        filterRow.add(filterLabel);
        filterRow.add(filterCombo);
        filterCombo.addActionListener(e -> load());
        center.add(filterRow, BorderLayout.NORTH);

        table.setRowHeight(26);
        TableStyler.style(table);
        center.add(new JScrollPane(table), BorderLayout.CENTER);

        add(center, BorderLayout.CENTER);
    }

    public void refresh() {
        load();
    }

    private void load() {
        LoginHistoryDAO.Filter filter = switch (filterCombo.getSelectedIndex()) {
            case 1 -> LoginHistoryDAO.Filter.SUCCESS_ONLY;
            case 2 -> LoginHistoryDAO.Filter.FAILED_ONLY;
            default -> LoginHistoryDAO.Filter.ALL;
        };

        new SwingWorker<List<LoginRecord>, Void>() {
            SQLException failure;
            @Override protected List<LoginRecord> doInBackground() {
                try { return dao.findAll(filter); } catch (SQLException e) { failure = e; return List.of(); }
            }
            @Override protected void done() {
                if (failure != null) {
                    JOptionPane.showMessageDialog(LoginHistoryPanel.this,
                            "Database error: " + failure.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                try {
                    model.setRowCount(0);
                    for (LoginRecord r : get()) {
                        model.addRow(new Object[]{
                                r.getLastName(), r.getFirstName(), r.getRole(),
                                DateTimeUtil.formatDate(r.getLoginTime()), DateTimeUtil.formatTime(r.getLoginTime()),
                                r.getStatus(), r.getIpAddress()
                        });
                    }
                } catch (Exception ignored) { }
            }
        }.execute();
    }
}
