package com.khierkian.ui.components;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;

public final class TableStyler {
    private TableStyler() {}

    public static void style(JTable table) {
        table.setBackground(Theme.TABLE_BG);
        table.setForeground(Theme.TABLE_TEXT);
        table.setSelectionBackground(Theme.TABLE_SELECTION);
        table.setSelectionForeground(Theme.TABLE_TEXT);
        table.setGridColor(new Color(255, 255, 255, 140));
        table.setRowHeight(28);
        table.setFillsViewportHeight(true);
        table.setIntercellSpacing(new Dimension(1, 1));

        table.getTableHeader().setBackground(Theme.TABLE_HEADER_BG);
        table.getTableHeader().setForeground(Theme.TABLE_TEXT);
        table.getTableHeader().setFont(Theme.FONT_LABEL);
        table.getTableHeader().setReorderingAllowed(false);

        DefaultTableCellRenderer center = new StripedCenterRenderer();
        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(center);
        }
    }

    /** Sets a preferred width (in px) per column, by index — call after style(). Widths are proportional hints,
     *  not hard limits, but they stop a column like "Arrived" (a full date+time) from being squeezed to nothing. */
    public static void setColumnWidths(JTable table, int... widths) {
        for (int i = 0; i < widths.length && i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        }
    }

    /** Centers text and gives alternating rows a faint stripe for readability. */
    private static class StripedCenterRenderer extends DefaultTableCellRenderer {
        StripedCenterRenderer() {
            setHorizontalAlignment(SwingConstants.CENTER);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                         boolean hasFocus, int row, int column) {
            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            if (!isSelected) {
                c.setBackground(row % 2 == 0 ? Theme.TABLE_BG : Theme.TABLE_BG_ALT);
            }
            return c;
        }
    }
}
