package com.khierkian.ui.components;

import org.apache.poi.xwpf.usermodel.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

/**
 * Builds a multi-section Word report — a real table per section, not just
 * plain text — and marks the finished document "Final" so Word opens it
 * read-only by default (a banner reads "Marked as Final" and typing is
 * disabled until someone deliberately clicks "Edit Anyway"). This is not
 * password-enforced protection — Word will let a user override it — but it
 * does what "not casually editable" needs without a password to manage.
 */
public final class DocxExportUtil {
    private DocxExportUtil() {}

    public record Section(String title, String[] headers, List<String[]> rows) {}

    public static void export(File file, String reportTitle, String generatedLine, List<Section> sections)
            throws IOException {
        try (XWPFDocument doc = new XWPFDocument()) {
            writeTitle(doc, reportTitle, generatedLine);

            for (Section section : sections) {
                writeSectionHeading(doc, section.title());
                writeTable(doc, section.headers(), section.rows());
                doc.createParagraph(); // spacing between sections
            }

            markAsFinal(doc);

            try (FileOutputStream out = new FileOutputStream(file)) {
                doc.write(out);
            }
        }
    }

    private static void writeTitle(XWPFDocument doc, String title, String generatedLine) {
        XWPFParagraph titlePara = doc.createParagraph();
        XWPFRun titleRun = titlePara.createRun();
        titleRun.setText(title);
        titleRun.setBold(true);
        titleRun.setFontSize(18);

        XWPFParagraph subPara = doc.createParagraph();
        XWPFRun subRun = subPara.createRun();
        subRun.setText(generatedLine);
        subRun.setFontSize(9);
        subRun.setColor("666666");
        subPara.setSpacingAfter(300);
    }

    private static void writeSectionHeading(XWPFDocument doc, String heading) {
        XWPFParagraph para = doc.createParagraph();
        para.setSpacingBefore(200);
        XWPFRun run = para.createRun();
        run.setText(heading);
        run.setBold(true);
        run.setFontSize(13);
    }

    private static void writeTable(XWPFDocument doc, String[] headers, List<String[]> rows) {
        XWPFTable table = doc.createTable(1, headers.length);
        table.setWidth("100%");

        XWPFTableRow headerRow = table.getRow(0);
        for (int col = 0; col < headers.length; col++) {
            XWPFTableCell cell = headerRow.getCell(col);
            setCellText(cell, headers[col], true);
            cell.setColor("D9E8F5");
        }

        if (rows.isEmpty()) {
            XWPFTableRow row = table.createRow();
            setCellText(row.getCell(0), "No records.", false);
            for (int col = 1; col < headers.length; col++) {
                setCellText(row.getCell(col), "", false);
            }
        } else {
            for (String[] rowData : rows) {
                XWPFTableRow row = table.createRow();
                for (int col = 0; col < headers.length && col < rowData.length; col++) {
                    setCellText(row.getCell(col), rowData[col], false);
                }
            }
        }
    }

    private static void setCellText(XWPFTableCell cell, String text, boolean bold) {
        cell.removeParagraph(0);
        XWPFParagraph para = cell.addParagraph();
        XWPFRun run = para.createRun();
        run.setText(text == null ? "" : text);
        run.setFontSize(9);
        run.setBold(bold);
    }

    /** Adds the standard OOXML "mark as final" custom property Word looks for. */
    private static void markAsFinal(XWPFDocument doc) {
        doc.getProperties().getCustomProperties().addProperty("_MarkAsFinal", true);
    }
}
