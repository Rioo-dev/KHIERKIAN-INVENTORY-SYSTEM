package com.khierkian.ui.components;

import javax.swing.*;
import java.awt.*;

/** A JButton with rounded corners and a soft vertical gradient, matching the login card style. */
public class RoundedButton extends JButton {

    private final int arc;

    public RoundedButton(String text, int arc) {
        super(text);
        this.arc = arc;
        setOpaque(false);
        setContentAreaFilled(false);
        setBorderPainted(false);
        setFocusPainted(false);
        setForeground(Color.WHITE);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();
        Color base = getBackground();
        Color top = base.brighter();
        Color bottom = base.darker();
        if (getModel().isPressed()) {
            top = base.darker();
            bottom = base.darker().darker();
        } else if (getModel().isRollover()) {
            top = base.brighter().brighter();
        }

        GradientPaint gradient = new GradientPaint(0, 0, top, 0, h, bottom);
        g2.setPaint(gradient);
        g2.fillRoundRect(0, 0, w - 1, h - 1, arc, arc);

        g2.setColor(new Color(255, 255, 255, 90));
        g2.setStroke(new BasicStroke(1.2f));
        g2.drawRoundRect(0, 0, w - 1, h - 1, arc, arc);

        g2.dispose();
        super.paintComponent(g);
    }
}
