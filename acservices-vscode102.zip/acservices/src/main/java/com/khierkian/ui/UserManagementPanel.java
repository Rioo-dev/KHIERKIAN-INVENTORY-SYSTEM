package com.khierkian.ui;

import com.khierkian.dao.UserDAO;
import com.khierkian.model.User;
import com.khierkian.ui.components.TableStyler;
import com.khierkian.ui.components.Theme;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.List;

public class UserManagementPanel extends JPanel {

    private final UserDAO dao = new UserDAO();

    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"ID", "Last Name", "First Name", "Username", "Phone", "Role", "Status"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JTextField txtSearch = new JTextField();
    private JButton deleteBtn;

    public UserManagementPanel() {
        setLayout(new BorderLayout());
        setBackground(Theme.CONTENT_BG);
        setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));

        JLabel heading = new JLabel("User Management");
        heading.setFont(Theme.FONT_TITLE);
        heading.setForeground(Theme.TEXT_ON_LIGHT);
        add(heading, BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(0, 10));
        center.setOpaque(false);
        center.setBorder(BorderFactory.createEmptyBorder(16, 0, 0, 0));

        JPanel topRow = new JPanel(new BorderLayout(8, 0));
        topRow.setOpaque(false);

        JButton addBtn = new JButton("+ Add New User");
        deleteBtn = new JButton("Delete Selected");
        deleteBtn.setEnabled(false);
        addBtn.addActionListener(e -> openUserDialog(null));
        deleteBtn.addActionListener(e -> deleteUser());

        JLabel hint = new JLabel("  (double-click a row to edit)");
        hint.setForeground(Theme.TEXT_MUTED_ON_LIGHT);
        hint.setFont(Theme.FONT_BODY);

        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        toolbar.setOpaque(false);
        toolbar.add(addBtn);
        toolbar.add(deleteBtn);
        toolbar.add(hint);
        topRow.add(toolbar, BorderLayout.WEST);

        JPanel searchRow = new JPanel(new BorderLayout(6, 0));
        searchRow.setOpaque(false);
        JLabel searchLabel = new JLabel("Search:");
        searchLabel.setForeground(Theme.TEXT_MUTED_ON_LIGHT);
        searchRow.add(searchLabel, BorderLayout.WEST);
        txtSearch.setPreferredSize(new Dimension(200, 28));
        searchRow.add(txtSearch, BorderLayout.CENTER);
        txtSearch.addActionListener(e -> search());
        JButton searchBtn = new JButton("Search");
        searchBtn.addActionListener(e -> search());
        JButton resetBtn = new JButton("Reset");
        resetBtn.addActionListener(e -> { txtSearch.setText(""); loadUsers(); });
        JPanel searchButtons = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        searchButtons.setOpaque(false);
        searchButtons.add(searchBtn);
        searchButtons.add(resetBtn);
        searchRow.add(searchButtons, BorderLayout.EAST);
        topRow.add(searchRow, BorderLayout.EAST);

        center.add(topRow, BorderLayout.NORTH);

        TableStyler.style(table);
        table.getSelectionModel().addListSelectionListener(e -> deleteBtn.setEnabled(table.getSelectedRow() >= 0));
        table.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && table.getSelectedRow() >= 0) {
                    openUserDialog(selectedUser());
                }
            }
        });
        center.add(new JScrollPane(table), BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);
    }

    private User selectedUser() {
        int row = table.getSelectedRow();
        if (row < 0) return null;
        return new User((Integer) model.getValueAt(row, 0), String.valueOf(model.getValueAt(row, 1)),
                String.valueOf(model.getValueAt(row, 2)), String.valueOf(model.getValueAt(row, 3)),
                String.valueOf(model.getValueAt(row, 5)), String.valueOf(model.getValueAt(row, 6)),
                String.valueOf(model.getValueAt(row, 4)));
    }

    private void openUserDialog(User existing) {
        boolean editing = existing != null;
        JDialog dialog = new JDialog(SwingUtilities.getWindowAncestor(this),
                editing ? "Edit User" : "Add New User", Dialog.ModalityType.APPLICATION_MODAL);
        dialog.setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(20, 24, 12, 24));
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(6, 6, 6, 6);
        gc.fill = GridBagConstraints.HORIZONTAL;

        JTextField txtLastName = new JTextField(editing ? existing.getLastName() : "", 18);
        JTextField txtFirstName = new JTextField(editing ? existing.getFirstName() : "", 18);
        JTextField txtUsername = new JTextField(editing ? existing.getUsername() : "", 18);
        JTextField txtPhone = new JTextField(editing && existing.getPhone() != null ? existing.getPhone() : "", 18);
        JPasswordField txtPassword = new JPasswordField(18);
        JComboBox<String> cmbRole = new JComboBox<>(new String[]{"Administrator", "Technical Staff"});
        JComboBox<String> cmbStatus = new JComboBox<>(new String[]{"Active", "Inactive", "Resigned"});
        if (editing) {
            cmbRole.setSelectedItem(existing.getRole());
            cmbStatus.setSelectedItem(existing.getStatus());
        }

        int row = 0;
        row = addFormRow(form, gc, row, "Last Name", txtLastName);
        row = addFormRow(form, gc, row, "First Name", txtFirstName);
        row = addFormRow(form, gc, row, "Username", txtUsername);
        row = addFormRow(form, gc, row, "Phone Number", txtPhone);
        row = addFormRow(form, gc, row,
                editing ? "New Password (leave blank to keep current)" : "Password", txtPassword);
        row = addFormRow(form, gc, row, "Role", cmbRole);
        addFormRow(form, gc, row, "Status", cmbStatus);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        JButton cancel = new JButton("Cancel");
        JButton save = new JButton(editing ? "Save Changes" : "Add User");
        cancel.addActionListener(e -> dialog.dispose());
        save.addActionListener(e -> {
            String lastName = txtLastName.getText().trim();
            String firstName = txtFirstName.getText().trim();
            String username = txtUsername.getText().trim();
            String phone = txtPhone.getText().trim();
            String password = new String(txtPassword.getPassword()).trim();
            String role = (String) cmbRole.getSelectedItem();
            String status = (String) cmbStatus.getSelectedItem();

            if (lastName.isEmpty() || firstName.isEmpty() || username.isEmpty() || (!editing && password.isEmpty())) {
                JOptionPane.showMessageDialog(dialog, "Please fill in all required fields.");
                return;
            }

            if (editing) {
                int id = existing.getId();
                runAsync(() -> dao.update(id, lastName, firstName, username, role, status, phone, password.isEmpty() ? null : password),
                        () -> { dialog.dispose(); loadUsers(); });
            } else {
                new SwingWorker<Boolean, Void>() {
                    SQLException failure;
                    @Override protected Boolean doInBackground() {
                        try {
                            if (dao.usernameExists(username)) return false;
                            dao.insert(lastName, firstName, username, password, role, status, phone);
                            return true;
                        } catch (SQLException ex) { failure = ex; return false; }
                    }
                    @Override protected void done() {
                        if (failure != null) { showDbError(failure); return; }
                        try {
                            if (!get()) {
                                JOptionPane.showMessageDialog(dialog, "Username already exists!");
                                return;
                            }
                        } catch (Exception ignored) { }
                        dialog.dispose();
                        loadUsers();
                    }
                }.execute();
            }
        });
        buttons.add(cancel);
        buttons.add(save);

        dialog.add(form, BorderLayout.CENTER);
        dialog.add(buttons, BorderLayout.SOUTH);
        dialog.getRootPane().setDefaultButton(save);
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void deleteUser() {
        User u = selectedUser();
        if (u == null) return;
        if (JOptionPane.showConfirmDialog(this, "Delete user \"" + u.getUsername() + "\"?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;

        new SwingWorker<UserDAO.DeleteOutcome, Void>() {
            SQLException failure;
            @Override protected UserDAO.DeleteOutcome doInBackground() {
                try { return dao.delete(u.getId()); } catch (SQLException e) { failure = e; return null; }
            }
            @Override protected void done() {
                if (failure != null) { showDbError(failure); return; }
                try {
                    if (get() == UserDAO.DeleteOutcome.LAST_ADMIN_BLOCKED) {
                        JOptionPane.showMessageDialog(UserManagementPanel.this,
                                "You cannot delete the last Administrator account!");
                        return;
                    }
                } catch (Exception ignored) { }
                loadUsers();
            }
        }.execute();
    }

    private void search() {
        String keyword = txtSearch.getText().trim();
        if (keyword.isEmpty()) { loadUsers(); return; }
        new SwingWorker<List<User>, Void>() {
            SQLException failure;
            @Override protected List<User> doInBackground() {
                try { return dao.search(keyword); } catch (SQLException e) { failure = e; return List.of(); }
            }
            @Override protected void done() {
                if (failure != null) { showDbError(failure); return; }
                try { populate(get()); } catch (Exception ignored) { }
            }
        }.execute();
    }

    public void refresh() {
        loadUsers();
    }

    private void loadUsers() {
        new SwingWorker<List<User>, Void>() {
            SQLException failure;
            @Override protected List<User> doInBackground() {
                try { return dao.findAll(); } catch (SQLException e) { failure = e; return List.of(); }
            }
            @Override protected void done() {
                if (failure != null) { showDbError(failure); return; }
                try { populate(get()); } catch (Exception ignored) { }
            }
        }.execute();
    }

    private void populate(List<User> users) {
        model.setRowCount(0);
        for (User u : users) {
            model.addRow(new Object[]{u.getId(), u.getLastName(), u.getFirstName(), u.getUsername(),
                    u.getPhone(), u.getRole(), u.getStatus()});
        }
        deleteBtn.setEnabled(false);
    }

    private int addFormRow(JPanel form, GridBagConstraints gc, int row, String label, JComponent field) {
        gc.gridx = 0;
        gc.gridy = row;
        gc.weightx = 0;
        JLabel l = new JLabel(label);
        l.setFont(Theme.FONT_LABEL);
        form.add(l, gc);

        gc.gridx = 1;
        gc.weightx = 1;
        form.add(field, gc);
        return row + 1;
    }

    private interface DbAction { void run() throws SQLException; }

    private void runAsync(DbAction action, Runnable onSuccess) {
        new SwingWorker<Void, Void>() {
            SQLException failure;
            @Override protected Void doInBackground() {
                try { action.run(); } catch (SQLException e) { failure = e; }
                return null;
            }
            @Override protected void done() {
                if (failure != null) { showDbError(failure); return; }
                onSuccess.run();
            }
        }.execute();
    }

    private void showDbError(SQLException e) {
        JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
