package com.khierkian.ui;

import com.khierkian.dao.LoginHistoryDAO;
import com.khierkian.dao.UserDAO;
import com.khierkian.session.Session;
import com.khierkian.ui.components.IconUtil;
import com.khierkian.ui.components.RoundedButton;
import com.khierkian.ui.components.RoundedPanel;
import com.khierkian.ui.components.RoundedPasswordField;
import com.khierkian.ui.components.RoundedTextField;
import com.khierkian.ui.components.Theme;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.font.TextAttribute;
import java.awt.geom.RoundRectangle2D;
import java.sql.SQLException;
import java.util.Map;

/**
 * Login screen: dark sign-in panel on the left, company info on the right.
 */
public class LoginFrame extends JFrame {

    // ======== Edit these to change the text shown on the right-hand side of the login screen ========
    private static final String COMPANY_INTRO =
            "KhierKian Air-Conditioning Services supplies, installs, and maintains air-conditioning units "
                    + "for homes and businesses. Our technicians keep your space cool, comfortable, and energy efficient.";
    private static final String[] SERVICES = {
            "Air-conditioning unit sales",
            "Installation and relocation",
            "Repair and maintenance",
            "Parts and materials supply"
    };
    private static final String REVIEW_TEXT =
            "Sample review: replace this with real feedback from one of your customers.";
    private static final String REVIEW_AUTHOR = "- Customer name";
    // ================================================================================================

    private final UserDAO userDAO = new UserDAO();
    private final LoginHistoryDAO historyDAO = new LoginHistoryDAO();

    private static final int MAX_ATTEMPTS = 3;
    private static final int LOCK_SECONDS = 15;
    private static final Color FIELD_BG = new Color(58, 68, 88);
    private static final Color SOFT_LINK = new Color(190, 214, 245);

    private int failedAttempts = 0;
    private boolean locked = false;
    private int secondsLeft = LOCK_SECONDS;
    private Timer countdownTimer;

    private final JTextField userField = new RoundedTextField(20, 8);
    private final JPasswordField passwordField = new RoundedPasswordField(20, 8);
    private final JCheckBox showPassword = new JCheckBox("Show password");
    private final JButton loginButton = new RoundedButton("LOGIN", 8);
    private final JLabel statusLabel = new JLabel(" ");

    public LoginFrame() {
        setTitle("KhierKian Air-Conditioning Services — Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setContentPane(buildContent());
        getRootPane().setDefaultButton(loginButton);
        setMinimumSize(new Dimension(1100, 700));
        pack();
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
    }

    private JComponent buildContent() {
        JPanel root = new JPanel(new GridBagLayout());
        root.setBackground(Theme.NAVY_DARK);

        JPanel left = buildLeftPanel();
        JPanel right = buildRightPanel();
        left.setPreferredSize(new Dimension(478, 620));
        right.setPreferredSize(new Dimension(562, 620));

        SplitCard card = new SplitCard(22, left);
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridy = 0;
        gc.fill = GridBagConstraints.BOTH;
        gc.weighty = 1;
        gc.gridx = 0;
        gc.weightx = 0.46;
        card.add(left, gc);
        gc.gridx = 1;
        gc.weightx = 0.54;
        card.add(right, gc);

        root.add(card);
        return root;
    }

    // ---------------- left: sign-in form ----------------

    private JPanel buildLeftPanel() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setOpaque(false);
        p.setBorder(BorderFactory.createEmptyBorder(34, 44, 34, 44));

        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = 0;
        gc.weightx = 1;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.anchor = GridBagConstraints.NORTHWEST;
        int row = 0;

        JPanel header = new JPanel(new BorderLayout(14, 0));
        header.setOpaque(false);
        ImageIcon logo = IconUtil.loadIcon("/images/logo.png", 84, 78);
        if (logo != null) {
            header.add(new JLabel(logo), BorderLayout.WEST);
        }
        JLabel name = new JLabel("<html>KhierKian Air-<br>Conditioning Services</html>");
        name.setFont(Theme.FONT_HEADING.deriveFont(Font.BOLD, 21f));
        name.setForeground(Theme.TEXT_LIGHT);
        header.add(name, BorderLayout.CENTER);
        gc.gridy = row++;
        p.add(header, gc);

        gc.gridy = row++;
        gc.insets = new Insets(48, 0, 6, 0);
        p.add(fieldLabel("Username"), gc);
        gc.gridy = row++;
        gc.insets = new Insets(0, 0, 0, 0);
        styleInput(userField);
        p.add(userField, gc);

        gc.gridy = row++;
        gc.insets = new Insets(20, 0, 6, 0);
        p.add(fieldLabel("Password"), gc);
        gc.gridy = row++;
        gc.insets = new Insets(0, 0, 0, 0);
        styleInput(passwordField);
        p.add(passwordField, gc);

        showPassword.setOpaque(false);
        showPassword.setForeground(Theme.TEXT_LIGHT);
        showPassword.setFont(Theme.FONT_BODY);
        showPassword.addActionListener(e ->
                passwordField.setEchoChar(showPassword.isSelected() ? (char) 0 : '\u2022'));

        JLabel forgot = new JLabel("Forgot Password");
        forgot.setFont(Theme.FONT_BODY.deriveFont(Font.ITALIC));
        forgot.setForeground(SOFT_LINK);
        forgot.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        forgot.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { showForgotPassword(); }
            @Override public void mouseEntered(MouseEvent e) { forgot.setForeground(Color.WHITE); }
            @Override public void mouseExited(MouseEvent e) { forgot.setForeground(SOFT_LINK); }
        });

        JPanel options = new JPanel(new BorderLayout());
        options.setOpaque(false);
        options.add(showPassword, BorderLayout.WEST);
        options.add(forgot, BorderLayout.EAST);
        gc.gridy = row++;
        gc.insets = new Insets(16, 0, 0, 0);
        p.add(options, gc);

        statusLabel.setFont(Theme.FONT_BODY);
        statusLabel.setForeground(Theme.DANGER);
        gc.gridy = row++;
        gc.insets = new Insets(14, 0, 0, 0);
        p.add(statusLabel, gc);

        Font base = Theme.FONT_HEADING.deriveFont(Font.BOLD, 15f);
        loginButton.setFont(base.deriveFont(Map.of(TextAttribute.TRACKING, 0.18f)));
        loginButton.setBackground(Theme.ACCENT);
        loginButton.setPreferredSize(new Dimension(100, 46));
        loginButton.addActionListener(this::onLogin);
        gc.gridy = row++;
        gc.insets = new Insets(16, 0, 0, 0);
        p.add(loginButton, gc);

        passwordField.addActionListener(this::onLogin);
        userField.addActionListener(this::onLogin);

        JPanel filler = new JPanel();
        filler.setOpaque(false);
        gc.gridy = row;
        gc.weighty = 1;
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = new Insets(0, 0, 0, 0);
        p.add(filler, gc);

        return p;
    }

    private void styleInput(JTextField field) {
        field.setPreferredSize(new Dimension(100, 42));
        field.setBackground(FIELD_BG);
        field.setForeground(Theme.TEXT_LIGHT);
        field.setFont(Theme.FONT_BODY.deriveFont(14f));
    }

    private JLabel fieldLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(Theme.FONT_LABEL);
        l.setForeground(Theme.TEXT_LIGHT);
        return l;
    }

    private void showForgotPassword() {
        JOptionPane.showMessageDialog(this,
                "Password resets are handled by an Administrator.\n\n"
                        + "Please contact your Administrator - they can set a new password for you in User Management.",
                "Forgot Password", JOptionPane.INFORMATION_MESSAGE);
    }

    // ---------------- right: company info ----------------

    private JPanel buildRightPanel() {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(BorderFactory.createEmptyBorder(44, 44, 40, 44));

        JLabel intro = new JLabel("<html><body style='width:440px'>" + html(COMPANY_INTRO) + "</body></html>");
        intro.setFont(Theme.FONT_BODY.deriveFont(16f));
        intro.setForeground(Theme.TEXT_ON_LIGHT);
        intro.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(intro);
        p.add(Box.createVerticalStrut(34));

        JLabel servicesTitle = new JLabel("Services");
        servicesTitle.setFont(Theme.FONT_HEADING.deriveFont(Font.BOLD, 20f));
        servicesTitle.setForeground(Theme.TEXT_ON_LIGHT);
        servicesTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(servicesTitle);
        p.add(Box.createVerticalStrut(10));
        for (String service : SERVICES) {
            JLabel bullet = new JLabel("\u2022   " + service);
            bullet.setFont(Theme.FONT_BODY.deriveFont(16f));
            bullet.setForeground(Theme.TEXT_ON_LIGHT);
            bullet.setAlignmentX(Component.LEFT_ALIGNMENT);
            p.add(bullet);
            p.add(Box.createVerticalStrut(6));
        }
        p.add(Box.createVerticalStrut(24));

        RoundedPanel review = new RoundedPanel(18, Theme.CONTENT_BG_SOFT, null);
        review.setLayout(new BoxLayout(review, BoxLayout.Y_AXIS));
        review.setBorder(BorderFactory.createEmptyBorder(20, 24, 22, 24));
        review.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel reviewTitle = new JLabel("Customer Review");
        reviewTitle.setFont(Theme.FONT_HEADING.deriveFont(Font.BOLD, 17f));
        reviewTitle.setForeground(Theme.TEXT_ON_LIGHT);
        reviewTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel quote = new JLabel("<html><body style='width:380px'>\u201C" + html(REVIEW_TEXT) + "\u201D</body></html>");
        quote.setFont(Theme.FONT_BODY.deriveFont(15f));
        quote.setForeground(Theme.TEXT_ON_LIGHT);
        quote.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel author = new JLabel(REVIEW_AUTHOR);
        author.setFont(Theme.FONT_BODY.deriveFont(Font.ITALIC, 14f));
        author.setForeground(Theme.TEXT_MUTED_ON_LIGHT);
        author.setAlignmentX(Component.LEFT_ALIGNMENT);

        review.add(reviewTitle);
        review.add(Box.createVerticalStrut(10));
        review.add(quote);
        review.add(Box.createVerticalStrut(12));
        review.add(author);
        p.add(review);
        p.add(Box.createVerticalGlue());

        return p;
    }

    private static String html(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    /** A rounded card painted in two tones: dark navy under the sign-in form, light blue under the company info. */
    private static class SplitCard extends JPanel {
        private final int arc;
        private final Component leftSide;

        SplitCard(int arc, Component leftSide) {
            this.arc = arc;
            this.leftSide = leftSide;
            setOpaque(false);
            setLayout(new GridBagLayout());
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            int split = leftSide.getX() + leftSide.getWidth();
            RoundRectangle2D.Float shape = new RoundRectangle2D.Float(0, 0, w - 1, h - 1, arc, arc);

            g2.setColor(Theme.CONTENT_BG);
            g2.fill(shape);
            g2.setClip(0, 0, split, h);
            g2.setColor(Theme.NAVY);
            g2.fill(shape);
            g2.dispose();
        }
    }

    private void onLogin(ActionEvent evt) {
        if (locked) {
            statusLabel.setText("Locked — wait " + secondsLeft + "s");
            return;
        }

        String username = userField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            statusLabel.setText("Enter both username and password.");
            return;
        }

        loginButton.setEnabled(false);
        statusLabel.setForeground(Theme.TEXT_MUTED);
        statusLabel.setText("Checking...");

        new SwingWorker<UserDAO.AuthResult, Void>() {
            SQLException failure;

            @Override
            protected UserDAO.AuthResult doInBackground() {
                try {
                    return userDAO.authenticate(username, password);
                } catch (SQLException e) {
                    failure = e;
                    return null;
                }
            }

            @Override
            protected void done() {
                loginButton.setEnabled(!locked);
                if (failure != null) {
                    statusLabel.setForeground(Theme.DANGER);
                    statusLabel.setText("Database error — check your connection.");
                    return;
                }

                UserDAO.AuthResult result;
                try {
                    result = get();
                } catch (Exception e) {
                    statusLabel.setForeground(Theme.DANGER);
                    statusLabel.setText("Unexpected error.");
                    return;
                }

                if (result.status == UserDAO.AuthStatus.SUCCESS) {
                    historyDAO.logAttempt(username, "SUCCESS");
                    Session.start(result.user.getId(), result.user.getUsername(),
                            result.user.getFirstName(), result.user.getLastName(), result.user.getRole(),
                            result.user.getPhone());
                    new MainFrame().setVisible(true);
                    dispose();
                } else if (result.status == UserDAO.AuthStatus.ACCOUNT_NOT_ACTIVE) {
                    historyDAO.logAttempt(username, "FAILED");
                    passwordField.setText("");
                    statusLabel.setForeground(Theme.DANGER);
                    statusLabel.setText("This account is " + result.user.getStatus() + ". Contact an Administrator.");
                } else {
                    historyDAO.logAttempt(username, "FAILED");
                    passwordField.setText("");
                    passwordField.requestFocus();
                    registerFailedAttempt();
                }
            }
        }.execute();
    }

    private void registerFailedAttempt() {
        failedAttempts++;
        if (failedAttempts >= MAX_ATTEMPTS) {
            startLockout();
        } else {
            statusLabel.setForeground(Theme.DANGER);
            statusLabel.setText("Invalid credentials. " + (MAX_ATTEMPTS - failedAttempts) + " attempt(s) left.");
        }
    }

    private void startLockout() {
        locked = true;
        loginButton.setEnabled(false);
        secondsLeft = LOCK_SECONDS;
        updateLockLabel();

        countdownTimer = new Timer(1000, e -> {
            secondsLeft--;
            if (secondsLeft > 0) {
                updateLockLabel();
            } else {
                countdownTimer.stop();
                locked = false;
                failedAttempts = 0;
                loginButton.setEnabled(true);
                loginButton.setText("LOGIN");
                statusLabel.setText(" ");
            }
        });
        countdownTimer.start();
    }

    private void updateLockLabel() {
        statusLabel.setForeground(Theme.WARNING);
        statusLabel.setText("Too many attempts. Wait " + secondsLeft + "s.");
        loginButton.setText("WAIT (" + secondsLeft + "s)");
    }
}
