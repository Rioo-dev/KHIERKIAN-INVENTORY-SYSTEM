package com.khierkian.dao;

import com.khierkian.db.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DashboardDAO {

    public record NameQty(String name, int quantity) {}

    public int totalAcUnits() throws SQLException {
        String sql = "SELECT COALESCE(SUM(quantity), 0) AS total FROM air_conditioning WHERE status != 'Out of Stock'";
        return scalarInt(sql);
    }

    public List<String> outOfStock(int limit) throws SQLException {
        String sql = "SELECT brand, model_no FROM air_conditioning "
                + "WHERE quantity <= 0 OR LOWER(status) = 'out of stock' LIMIT " + limit;
        List<String> out = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                out.add(rs.getString("brand") + " " + rs.getString("model_no"));
            }
        }
        return out;
    }

    public int totalMaterials() throws SQLException {
        return scalarInt("SELECT COALESCE(SUM(quantity), 0) AS total FROM materials");
    }

    public List<String> recentMaterialNames(int limit) throws SQLException {
        String sql = "SELECT name FROM materials ORDER BY id DESC LIMIT " + limit;
        List<String> out = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                out.add(rs.getString("name"));
            }
        }
        return out;
    }

    public List<NameQty> lowStock(int limit) throws SQLException {
        String sql = "SELECT brand, model_no, quantity FROM air_conditioning "
                + "WHERE quantity > 0 AND quantity <= 10 ORDER BY quantity ASC LIMIT " + limit;
        return nameQtyList(sql);
    }

    public List<String> topSelling(int limit) throws SQLException {
        String sql = "SELECT brand, model_no FROM air_conditioning ORDER BY quantity DESC LIMIT " + limit;
        List<String> out = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                out.add(rs.getString("brand") + " " + rs.getString("model_no"));
            }
        }
        return out;
    }

    public List<NameQty> reorderMonitor(int limit) throws SQLException {
        String sql = "SELECT model_no, quantity FROM air_conditioning ORDER BY quantity ASC LIMIT " + limit;
        return nameQtyList(sql);
    }

    private List<NameQty> nameQtyList(String sql) throws SQLException {
        List<NameQty> out = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                // Works for both (brand, model_no) and (model_no) shaped queries above.
                String name = hasColumn(rs, "brand")
                        ? rs.getString("brand") + " " + rs.getString("model_no")
                        : rs.getString("model_no");
                out.add(new NameQty(name, rs.getInt("quantity")));
            }
        }
        return out;
    }

    private boolean hasColumn(ResultSet rs, String column) throws SQLException {
        int cols = rs.getMetaData().getColumnCount();
        for (int i = 1; i <= cols; i++) {
            if (rs.getMetaData().getColumnLabel(i).equalsIgnoreCase(column)) {
                return true;
            }
        }
        return false;
    }

    private int scalarInt(String sql) throws SQLException {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }
}
