package com.khierkian.dao;

import com.khierkian.db.DBConnection;
import com.khierkian.model.LoginRecord;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LoginHistoryDAO {

    /** Records a login attempt; looks up name/role from users if the username matched a real account. */
    public void logAttempt(String username, String status) {
        String sql = "INSERT INTO login_history (username, last_name, first_name, role, login_time, status, ip_address) "
                + "SELECT username, COALESCE(last_name, 'Unknown'), COALESCE(first_name, 'Unknown'), COALESCE(role, 'N/A'), "
                + "NOW(), ?, '127.0.0.1' FROM users WHERE username = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, status);
            pst.setString(2, username);
            int rows = pst.executeUpdate();

            if (rows == 0) {
                String fallback = "INSERT INTO login_history (username, last_name, first_name, role, login_time, status, ip_address) "
                        + "VALUES (?, 'Unknown', 'Unknown', 'N/A', NOW(), ?, '127.0.0.1')";
                try (PreparedStatement pst2 = con.prepareStatement(fallback)) {
                    pst2.setString(1, username);
                    pst2.setString(2, status);
                    pst2.executeUpdate();
                }
            }
        } catch (SQLException e) {
            // A failed audit-log write should never block login itself — just log it.
            System.err.println("Failed to log attempt: " + e.getMessage());
        }
    }

    public enum Filter { ALL, SUCCESS_ONLY, FAILED_ONLY }

    public List<LoginRecord> findAll(Filter filter) throws SQLException {
        return findAll(filter, null);
    }

    /** days: null = no date restriction — used by the Report screen's period picker. */
    public List<LoginRecord> findAll(Filter filter, Integer days) throws SQLException {
        StringBuilder sql = new StringBuilder(
                "SELECT last_name, first_name, role, login_time, status, ip_address FROM login_history WHERE 1=1");
        List<Object> params = new ArrayList<>();

        if (filter == Filter.SUCCESS_ONLY) {
            sql.append(" AND status = 'SUCCESS'");
        } else if (filter == Filter.FAILED_ONLY) {
            sql.append(" AND status = 'FAILED'");
        }
        if (days != null) {
            sql.append(" AND login_time >= (NOW() - INTERVAL ? DAY)");
            params.add(days);
        }
        sql.append(" ORDER BY login_time DESC");

        List<LoginRecord> out = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                pst.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    out.add(new LoginRecord(rs.getString("last_name"), rs.getString("first_name"),
                            rs.getString("role"), rs.getTimestamp("login_time"),
                            rs.getString("status"), rs.getString("ip_address")));
                }
            }
        }
        return out;
    }
}
