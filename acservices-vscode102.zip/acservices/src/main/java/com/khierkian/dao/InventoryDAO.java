package com.khierkian.dao;

import com.khierkian.db.DBConnection;
import com.khierkian.model.AirConditioningUnit;
import com.khierkian.model.Material;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class InventoryDAO {

    /** Preset ranges for the "Arrival" filter — a full date-range picker isn't worth the Swing plumbing here. */
    public enum ArrivalFilter {
        ANY(null), TODAY(1), LAST_7_DAYS(7), LAST_30_DAYS(30);
        public final Integer days;
        ArrivalFilter(Integer days) { this.days = days; }
    }

    // ---------- Air Conditioning Units ----------

    public List<AirConditioningUnit> findAllUnits() throws SQLException {
        return filterUnits(null, null, null, ArrivalFilter.ANY);
    }

    /** keyword matches brand/model/serial. type/status pass "All" (or null) to skip that filter. */
    public List<AirConditioningUnit> filterUnits(String keyword, String type, String status, ArrivalFilter arrival)
            throws SQLException {
        return filterUnits(keyword, type, status, arrival == null ? null : arrival.days);
    }

    /** Same as above, but takes a raw day count (null = no date restriction) — used by the Report screen's period picker. */
    public List<AirConditioningUnit> filterUnits(String keyword, String type, String status, Integer arrivalDays)
            throws SQLException {
        StringBuilder sql = new StringBuilder(
                "SELECT id, brand, model_no, specifications, type, quantity, status, serial_no, date_arrived "
                        + "FROM air_conditioning WHERE 1=1");
        List<Object> params = new ArrayList<>();

        if (keyword != null && !keyword.isBlank()) {
            sql.append(" AND (brand LIKE ? OR model_no LIKE ? OR serial_no LIKE ?)");
            String like = "%" + keyword + "%";
            params.add(like); params.add(like); params.add(like);
        }
        if (type != null && !type.equalsIgnoreCase("All")) {
            sql.append(" AND type = ?");
            params.add(type);
        }
        if (status != null && !status.equalsIgnoreCase("All")) {
            sql.append(" AND status = ?");
            params.add(status);
        }
        if (arrivalDays != null) {
            sql.append(" AND date_arrived >= (NOW() - INTERVAL ? DAY)");
            params.add(arrivalDays);
        }
        sql.append(" ORDER BY id ASC");

        List<AirConditioningUnit> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                pst.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    list.add(mapUnit(rs));
                }
            }
        }
        return list;
    }

    /** Looks up a unit by its Serial No. — the value AC unit barcodes/QR codes are expected to hold. */
    public Optional<AirConditioningUnit> findUnitBySerial(String serial) throws SQLException {
        String sql = "SELECT id, brand, model_no, specifications, type, quantity, status, serial_no, date_arrived "
                + "FROM air_conditioning WHERE serial_no = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, serial);
            try (ResultSet rs = pst.executeQuery()) {
                return rs.next() ? Optional.of(mapUnit(rs)) : Optional.empty();
            }
        }
    }

    private AirConditioningUnit mapUnit(ResultSet rs) throws SQLException {
        return new AirConditioningUnit(
                rs.getInt("id"), rs.getString("brand"), rs.getString("model_no"),
                rs.getString("specifications"), rs.getString("type"), rs.getInt("quantity"),
                rs.getString("status"), rs.getString("serial_no"), rs.getTimestamp("date_arrived"));
    }

    public void insertUnit(String brand, String modelNo, String specifications, String type,
                            int quantity, String status, String serialNo) throws SQLException {
        String sql = "INSERT INTO air_conditioning (brand, model_no, specifications, type, quantity, status, date_sold, serial_no, date_arrived) "
                + "VALUES (?, ?, ?, ?, ?, ?, NULL, ?, NOW())";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, brand);
            pst.setString(2, modelNo);
            pst.setString(3, specifications);
            pst.setString(4, type);
            pst.setInt(5, quantity);
            pst.setString(6, status);
            pst.setString(7, serialNo);
            pst.executeUpdate();
        }
    }

    /**
     * Auto-creates a new AC unit from a phone scan of a code that matched nothing.
     * A barcode only encodes a serial number — it has no idea what the brand, model,
     * or type actually are — so this fills those in with clear placeholders and
     * relies on someone finishing the real details later in the desktop Inventory screen.
     * Quantity starts at 1 (the unit just scanned in) and Status "Available".
     */
    public AirConditioningUnit registerNewUnitFromScan(String serialNo) throws SQLException {
        String sql = "INSERT INTO air_conditioning (brand, model_no, specifications, type, quantity, status, date_sold, serial_no, date_arrived) "
                + "VALUES ('Unregistered', ?, 'Added via scan - needs details', 'Unspecified', 1, 'Available', NULL, ?, NOW())";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql, java.sql.Statement.RETURN_GENERATED_KEYS)) {
            pst.setString(1, serialNo);
            pst.setString(2, serialNo);
            pst.executeUpdate();
            int newId;
            try (ResultSet keys = pst.getGeneratedKeys()) {
                keys.next();
                newId = keys.getInt(1);
            }
            try (PreparedStatement lookup = con.prepareStatement(
                    "SELECT id, brand, model_no, specifications, type, quantity, status, serial_no, date_arrived "
                            + "FROM air_conditioning WHERE id=?")) {
                lookup.setInt(1, newId);
                try (ResultSet rs = lookup.executeQuery()) {
                    rs.next();
                    return mapUnit(rs);
                }
            }
        }
    }

    public void updateUnit(int id, String brand, String modelNo, String specifications, String type,
                            int quantity, String status, String serialNo) throws SQLException {
        String sql = "UPDATE air_conditioning SET brand=?, model_no=?, specifications=?, type=?, "
                + "quantity=?, status=?, serial_no=? WHERE id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, brand);
            pst.setString(2, modelNo);
            pst.setString(3, specifications);
            pst.setString(4, type);
            pst.setInt(5, quantity);
            pst.setString(6, status);
            pst.setString(7, serialNo);
            pst.setInt(8, id);
            pst.executeUpdate();
        }
    }

    public void deleteUnit(int id) throws SQLException {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement("DELETE FROM air_conditioning WHERE id=?")) {
            pst.setInt(1, id);
            pst.executeUpdate();
        }
    }

    /**
     * Adds delta (positive or negative) to a unit's quantity from a scan, clamped at 0,
     * and recomputes status from simple thresholds. Returns the unit's new state.
     */
    public AirConditioningUnit adjustUnitQuantity(int id, int delta) throws SQLException {
        try (Connection con = DBConnection.getConnection()) {
            int newQty;
            try (PreparedStatement pst = con.prepareStatement(
                    "SELECT quantity FROM air_conditioning WHERE id=?")) {
                pst.setInt(1, id);
                try (ResultSet rs = pst.executeQuery()) {
                    if (!rs.next()) throw new SQLException("Unit not found");
                    newQty = Math.max(0, rs.getInt("quantity") + delta);
                }
            }
            String status = newQty <= 0 ? "Out of Stock" : (newQty <= 5 ? "Low Stock" : "Available");
            try (PreparedStatement pst = con.prepareStatement(
                    "UPDATE air_conditioning SET quantity=?, status=? WHERE id=?")) {
                pst.setInt(1, newQty);
                pst.setString(2, status);
                pst.setInt(3, id);
                pst.executeUpdate();
            }
            try (PreparedStatement pst = con.prepareStatement(
                    "SELECT id, brand, model_no, specifications, type, quantity, status, serial_no, date_arrived "
                            + "FROM air_conditioning WHERE id=?")) {
                pst.setInt(1, id);
                try (ResultSet rs = pst.executeQuery()) {
                    rs.next();
                    return mapUnit(rs);
                }
            }
        }
    }

    // ---------- Materials ----------

    public List<Material> findAllMaterials() throws SQLException {
        return filterMaterials(null, null, null, null);
    }

    public List<Material> filterMaterials(String keyword, String unit, String type, String acType) throws SQLException {
        return filterMaterials(keyword, unit, type, acType, null);
    }

    /** arrivalDays: null = no date restriction — used by the Report screen's period picker. */
    public List<Material> filterMaterials(String keyword, String unit, String type, String acType, Integer arrivalDays)
            throws SQLException {
        StringBuilder sql = new StringBuilder(
                "SELECT id, name, unit_of_measure, quantity, type, ac_type, date_arrived, barcode FROM materials WHERE 1=1");
        List<Object> params = new ArrayList<>();

        if (keyword != null && !keyword.isBlank()) {
            sql.append(" AND name LIKE ?");
            params.add("%" + keyword + "%");
        }
        if (unit != null && !unit.equalsIgnoreCase("All")) {
            sql.append(" AND unit_of_measure = ?");
            params.add(unit);
        }
        if (type != null && !type.equalsIgnoreCase("All")) {
            sql.append(" AND type = ?");
            params.add(type);
        }
        if (acType != null && !acType.equalsIgnoreCase("All")) {
            sql.append(" AND ac_type = ?");
            params.add(acType);
        }
        if (arrivalDays != null) {
            sql.append(" AND date_arrived >= (NOW() - INTERVAL ? DAY)");
            params.add(arrivalDays);
        }
        sql.append(" ORDER BY id ASC");

        List<Material> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                pst.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    list.add(mapMaterial(rs));
                }
            }
        }
        return list;
    }

    public Optional<Material> findMaterialByBarcode(String barcode) throws SQLException {
        String sql = "SELECT id, name, unit_of_measure, quantity, type, ac_type, date_arrived, barcode "
                + "FROM materials WHERE barcode = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, barcode);
            try (ResultSet rs = pst.executeQuery()) {
                return rs.next() ? Optional.of(mapMaterial(rs)) : Optional.empty();
            }
        }
    }

    private Material mapMaterial(ResultSet rs) throws SQLException {
        return new Material(rs.getInt("id"), rs.getString("name"), rs.getString("unit_of_measure"),
                rs.getInt("quantity"), rs.getString("type"), rs.getString("ac_type"),
                rs.getTimestamp("date_arrived"), rs.getString("barcode"));
    }

    public void insertMaterial(String name, String unitOfMeasure, int quantity, String type, String acType,
                                String barcode) throws SQLException {
        String sql = "INSERT INTO materials (name, unit_of_measure, quantity, type, ac_type, date_arrived, barcode) "
                + "VALUES (?, ?, ?, ?, ?, NOW(), ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, name);
            pst.setString(2, unitOfMeasure);
            pst.setInt(3, quantity);
            pst.setString(4, type);
            pst.setString(5, acType);
            pst.setString(6, barcode);
            pst.executeUpdate();
        }
    }

    public void updateMaterial(int id, String name, String unitOfMeasure, int quantity, String type, String acType,
                                String barcode) throws SQLException {
        String sql = "UPDATE materials SET name=?, unit_of_measure=?, quantity=?, type=?, ac_type=?, barcode=? WHERE id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, name);
            pst.setString(2, unitOfMeasure);
            pst.setInt(3, quantity);
            pst.setString(4, type);
            pst.setString(5, acType);
            pst.setString(6, barcode);
            pst.setInt(7, id);
            pst.executeUpdate();
        }
    }

    public void deleteMaterial(int id) throws SQLException {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement("DELETE FROM materials WHERE id=?")) {
            pst.setInt(1, id);
            pst.executeUpdate();
        }
    }

    /** Adds delta (positive or negative) to a material's quantity from a scan, clamped at 0. */
    public Material adjustMaterialQuantity(int id, int delta) throws SQLException {
        try (Connection con = DBConnection.getConnection()) {
            int newQty;
            try (PreparedStatement pst = con.prepareStatement("SELECT quantity FROM materials WHERE id=?")) {
                pst.setInt(1, id);
                try (ResultSet rs = pst.executeQuery()) {
                    if (!rs.next()) throw new SQLException("Material not found");
                    newQty = Math.max(0, rs.getInt("quantity") + delta);
                }
            }
            try (PreparedStatement pst = con.prepareStatement("UPDATE materials SET quantity=? WHERE id=?")) {
                pst.setInt(1, newQty);
                pst.setInt(2, id);
                pst.executeUpdate();
            }
            try (PreparedStatement pst = con.prepareStatement(
                    "SELECT id, name, unit_of_measure, quantity, type, ac_type, date_arrived, barcode "
                            + "FROM materials WHERE id=?")) {
                pst.setInt(1, id);
                try (ResultSet rs = pst.executeQuery()) {
                    rs.next();
                    return mapMaterial(rs);
                }
            }
        }
    }
}
