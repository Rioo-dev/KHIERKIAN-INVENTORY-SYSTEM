package com.khierkian.dao;

import com.khierkian.db.DBConnection;
import com.khierkian.db.PasswordUtil;
import com.khierkian.model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    public enum AuthStatus { SUCCESS, INVALID_CREDENTIALS, ACCOUNT_NOT_ACTIVE }

    /** Result of an authentication attempt. */
    public static class AuthResult {
        public final AuthStatus status;
        public final User user;
        public AuthResult(AuthStatus status, User user) {
            this.status = status;
            this.user = user;
        }
    }

    public AuthResult authenticate(String username, String password) throws SQLException {
        String sql = "SELECT id, last_name, first_name, username, password, role, status, phone FROM users WHERE username = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, username);
            try (ResultSet rs = pst.executeQuery()) {
                if (!rs.next()) {
                    return new AuthResult(AuthStatus.INVALID_CREDENTIALS, null);
                }
                String stored = rs.getString("password");
                if (!PasswordUtil.matches(password, stored)) {
                    return new AuthResult(AuthStatus.INVALID_CREDENTIALS, null);
                }

                int id = rs.getInt("id");
                String status = rs.getString("status");
                User user = new User(id, rs.getString("last_name"), rs.getString("first_name"),
                        rs.getString("username"), rs.getString("role"), status, rs.getString("phone"));

                if (status != null && !status.equalsIgnoreCase("Active")) {
                    return new AuthResult(AuthStatus.ACCOUNT_NOT_ACTIVE, user);
                }

                // Auto-migrate legacy plaintext rows to a BCrypt hash on successful login.
                if (!PasswordUtil.isBcryptHash(stored)) {
                    rehashPassword(id, password);
                }

                return new AuthResult(AuthStatus.SUCCESS, user);
            }
        }
    }

    private void rehashPassword(int userId, String plainPassword) throws SQLException {
        String sql = "UPDATE users SET password = ? WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, PasswordUtil.hash(plainPassword));
            pst.setInt(2, userId);
            pst.executeUpdate();
        }
    }

    public List<User> findAll() throws SQLException {
        String sql = "SELECT id, last_name, first_name, username, role, status, phone FROM users ORDER BY id ASC";
        List<User> users = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                users.add(mapRow(rs));
            }
        }
        return users;
    }

    public List<User> search(String keyword) throws SQLException {
        String sql = "SELECT id, last_name, first_name, username, role, status, phone FROM users "
                + "WHERE last_name LIKE ? OR first_name LIKE ? OR username LIKE ? OR role LIKE ? OR status LIKE ? OR phone LIKE ? "
                + "ORDER BY id ASC";
        List<User> users = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            String search = "%" + keyword + "%";
            for (int i = 1; i <= 6; i++) {
                pst.setString(i, search);
            }
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    users.add(mapRow(rs));
                }
            }
        }
        return users;
    }

    private User mapRow(ResultSet rs) throws SQLException {
        return new User(rs.getInt("id"), rs.getString("last_name"), rs.getString("first_name"),
                rs.getString("username"), rs.getString("role"), rs.getString("status"), rs.getString("phone"));
    }

    public boolean usernameExists(String username) throws SQLException {
        String sql = "SELECT 1 FROM users WHERE username = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, username);
            try (ResultSet rs = pst.executeQuery()) {
                return rs.next();
            }
        }
    }

    public void insert(String lastName, String firstName, String username, String plainPassword, String role,
                        String status, String phone) throws SQLException {
        String sql = "INSERT INTO users(last_name, first_name, username, password, role, status, phone) VALUES (?,?,?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, lastName);
            pst.setString(2, firstName);
            pst.setString(3, username);
            pst.setString(4, PasswordUtil.hash(plainPassword));
            pst.setString(5, role);
            pst.setString(6, status);
            pst.setString(7, phone);
            pst.executeUpdate();
        }
    }

    /** Updates profile fields (used by User Management); only rehashes the password if a new one was provided. */
    public void update(int id, String lastName, String firstName, String username, String role, String status,
                        String phone, String newPlainPasswordOrNull) throws SQLException {
        String sql;
        boolean changePassword = newPlainPasswordOrNull != null && !newPlainPasswordOrNull.isEmpty();
        if (changePassword) {
            sql = "UPDATE users SET last_name=?, first_name=?, username=?, password=?, role=?, status=?, phone=? WHERE id=?";
        } else {
            sql = "UPDATE users SET last_name=?, first_name=?, username=?, role=?, status=?, phone=? WHERE id=?";
        }
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, lastName);
            pst.setString(2, firstName);
            pst.setString(3, username);
            if (changePassword) {
                pst.setString(4, PasswordUtil.hash(newPlainPasswordOrNull));
                pst.setString(5, role);
                pst.setString(6, status);
                pst.setString(7, phone);
                pst.setInt(8, id);
            } else {
                pst.setString(4, role);
                pst.setString(5, status);
                pst.setString(6, phone);
                pst.setInt(7, id);
            }
            pst.executeUpdate();
        }
    }

    /**
     * Lets a logged-in user edit their own contact details from the sidebar —
     * first/last name and phone only. Role and username are never touched here.
     */
    public void updateOwnProfile(int id, String firstName, String lastName, String phone) throws SQLException {
        String sql = "UPDATE users SET first_name=?, last_name=?, phone=? WHERE id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, firstName);
            pst.setString(2, lastName);
            pst.setString(3, phone);
            pst.setInt(4, id);
            pst.executeUpdate();
        }
    }

    /** Mirrors the original "can't delete the last Administrator" rule. */
    public DeleteOutcome delete(int id) throws SQLException {
        try (Connection con = DBConnection.getConnection()) {
            String role = null;
            try (PreparedStatement rolePst = con.prepareStatement("SELECT role FROM users WHERE id=?")) {
                rolePst.setInt(1, id);
                try (ResultSet rs = rolePst.executeQuery()) {
                    if (rs.next()) {
                        role = rs.getString("role");
                    }
                }
            }

            if ("Administrator".equals(role)) {
                try (PreparedStatement countPst = con.prepareStatement(
                        "SELECT COUNT(*) FROM users WHERE role='Administrator'");
                     ResultSet rs = countPst.executeQuery()) {
                    if (rs.next() && rs.getInt(1) <= 1) {
                        return DeleteOutcome.LAST_ADMIN_BLOCKED;
                    }
                }
            }

            try (PreparedStatement pst = con.prepareStatement("DELETE FROM users WHERE id=?")) {
                pst.setInt(1, id);
                pst.executeUpdate();
            }
            return DeleteOutcome.DELETED;
        }
    }

    public enum DeleteOutcome { DELETED, LAST_ADMIN_BLOCKED }
}
