package com.khierkian.dao;

import com.khierkian.db.DBConnection;
import com.khierkian.model.ActivityLogEntry;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ActivityLogDAO {

    /** Records a staff action. Never throws — a failed audit write should never block the actual operation. */
    public void log(String username, String action, String description) {
        String sql = "INSERT INTO activity_log (username, action, description, action_time) VALUES (?, ?, ?, NOW())";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, username);
            pst.setString(2, action);
            pst.setString(3, description);
            pst.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Failed to write activity log: " + e.getMessage());
        }
    }

    public List<ActivityLogEntry> findAll() throws SQLException {
        return findAll(null);
    }

    /** days: null = no date restriction — used by the Report screen's period picker. */
    public List<ActivityLogEntry> findAll(Integer days) throws SQLException {
        StringBuilder sql = new StringBuilder(
                "SELECT username, action, description, action_time FROM activity_log WHERE 1=1");
        List<Object> params = new ArrayList<>();
        if (days != null) {
            sql.append(" AND action_time >= (NOW() - INTERVAL ? DAY)");
            params.add(days);
        }
        sql.append(" ORDER BY action_time DESC");

        List<ActivityLogEntry> out = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                pst.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    out.add(new ActivityLogEntry(rs.getString("username"), rs.getString("action"),
                            rs.getString("description"), rs.getTimestamp("action_time")));
                }
            }
        }
        return out;
    }
}
