package com.khierkian.session;

/**
 * Holds the currently logged-in user for the lifetime of the app.
 * Kept as a simple static holder (same idea as the original app) —
 * fine for a single-user desktop session; would need to become an
 * instance passed through the UI if this ever supported multiple
 * concurrent windows/users in one JVM.
 */
public final class Session {

    private static int userId = -1;
    private static String username;
    private static String firstName;
    private static String lastName;
    private static String role;
    private static String phone;

    private Session() {
    }

    public static void start(int id, String username, String firstName, String lastName, String role, String phone) {
        Session.userId = id;
        Session.username = username;
        Session.firstName = firstName;
        Session.lastName = lastName;
        Session.role = role;
        Session.phone = phone;
    }

    /** Updates just the editable contact fields, after a self-profile save — keeps id/username/role as-is. */
    public static void updateProfile(String firstName, String lastName, String phone) {
        Session.firstName = firstName;
        Session.lastName = lastName;
        Session.phone = phone;
    }

    public static void clear() {
        userId = -1;
        username = null;
        firstName = null;
        lastName = null;
        role = null;
        phone = null;
    }

    public static boolean isAdmin() {
        return "Administrator".equalsIgnoreCase(role);
    }

    public static int getUserId() {
        return userId;
    }

    public static String getUsername() {
        return username;
    }

    public static String getFirstName() {
        return firstName;
    }

    public static String getLastName() {
        return lastName;
    }

    public static String getRole() {
        return role;
    }

    public static String getPhone() {
        return phone;
    }

    public static String getFullName() {
        return (firstName == null ? "" : firstName) + " " + (lastName == null ? "" : lastName);
    }
}
