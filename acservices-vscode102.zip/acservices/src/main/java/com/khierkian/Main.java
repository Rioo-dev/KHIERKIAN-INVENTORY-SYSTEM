package com.khierkian;

import com.formdev.flatlaf.FlatLightLaf;
import com.khierkian.ui.LoginFrame;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        FlatLightLaf.setup();
        UIManager.put("defaultFont", com.khierkian.ui.components.Theme.FONT_BODY);

        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
