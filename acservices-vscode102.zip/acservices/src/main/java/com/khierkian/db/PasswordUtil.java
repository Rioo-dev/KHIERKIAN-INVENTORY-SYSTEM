package com.khierkian.db;

import org.mindrot.jbcrypt.BCrypt;

/**
 * All password hashing goes through here so it's never done ad-hoc in a
 * button handler again.
 */
public final class PasswordUtil {

    private PasswordUtil() {
    }

    public static String hash(String plainPassword) {
        return BCrypt.hashpw(plainPassword, BCrypt.gensalt(12));
    }

    /**
     * Verifies a login attempt. Supports BCrypt hashes ($2a$/$2b$/$2y$
     * prefix). If the stored value isn't a BCrypt hash, it's treated as a
     * legacy plaintext password (in case you're migrating an existing
     * database) and compared directly — callers should re-hash and save on
     * a successful legacy match so accounts migrate automatically over time.
     */
    public static boolean matches(String plainPassword, String storedValue) {
        if (storedValue == null || plainPassword == null) {
            return false;
        }
        if (isBcryptHash(storedValue)) {
            return BCrypt.checkpw(plainPassword, storedValue);
        }
        return storedValue.equals(plainPassword);
    }

    public static boolean isBcryptHash(String value) {
        return value.startsWith("$2a$") || value.startsWith("$2b$") || value.startsWith("$2y$");
    }

    /** Command-line helper: prints a BCrypt hash for a password you type as an argument.
     *  Use this to create your first admin row — see README "First-time setup". */
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java com.khierkian.db.PasswordUtil <password>");
            return;
        }
        System.out.println(hash(args[0]));
    }
}
