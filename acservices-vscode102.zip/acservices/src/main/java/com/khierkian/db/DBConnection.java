package com.khierkian.db;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Single place that knows how to open a JDBC connection.
 * Credentials live in src/main/resources/db.properties (not committed with
 * real passwords in a real project — see README).
 */
public final class DBConnection {

    private static final Properties PROPS = new Properties();
    private static volatile boolean loaded = false;

    private DBConnection() {
    }

    private static void loadProperties() {
        if (loaded) {
            return;
        }
        try (InputStream in = DBConnection.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (in == null) {
                throw new IllegalStateException("db.properties not found on classpath");
            }
            PROPS.load(in);
            loaded = true;
        } catch (IOException e) {
            throw new IllegalStateException("Could not load db.properties", e);
        }
    }

    /**
     * Opens a fresh connection. Caller is responsible for closing it
     * (use try-with-resources) — mirrors the original app's pattern so
     * every DAO method stays simple and leak-free.
     */
    public static Connection getConnection() throws SQLException {
        loadProperties();
        String url = PROPS.getProperty("db.url");
        String user = PROPS.getProperty("db.user");
        String password = PROPS.getProperty("db.password");
        return DriverManager.getConnection(url, user, password);
    }

    /** Quick manual check: run this to confirm your credentials work. */
    public static void main(String[] args) {
        try (Connection con = getConnection()) {
            System.out.println("Connected OK: " + con.getMetaData().getURL());
        } catch (SQLException e) {
            System.err.println("Connection failed: " + e.getMessage());
        }
    }
}
