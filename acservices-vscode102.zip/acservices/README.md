# KhierKian Air-Conditioning Services

Rebuilt from the original NetBeans GUI-builder project into a plain Maven
project you can open and run in VS Code. Same features (login, dashboard,
inventory, user management, login history), rebuilt as:

- **One window, `CardLayout` panels** instead of a new `JFrame` per screen —
  navigation no longer flickers or reloads the whole app.
- **Hashed passwords** (BCrypt) instead of plaintext SQL comparison. Existing
  plaintext rows still log in and get silently upgraded to a hash on their
  next successful login.
- **DAO layer** (`com.khierkian.dao.*`) — all SQL lives there now, not
  scattered through UI event handlers.
- **FlatLaf** look and feel instead of Nimbus.
- **`SwingWorker`** for every DB call so the UI never freezes.
- No hardcoded `C:\Users\...` image paths.

- **Reports → Export to Excel**: Administrators can export the AC Units
  and Materials reports to a real `.xlsx` file (Apache POI).
- **Sidebar user chip**: click your name/role in the sidebar to open a
  small popup with your full account info and the Log Out button — Log
  Out is no longer a permanent sidebar button.
- **All timestamps are GMT+8, numeric only** (`08/26/2026 14:30`, no
  "Aug"-style month names) — Inventory arrival times, Login History, and
  Activity Log all use the same shared formatter.
- **Larger, bolder Dashboard text** — card headings and body text are
  easier to read from a distance.
- Login screen fields and button are now centered under the logo/title.

## What's new in this revision

- **Role-based Inventory access**: Technical Staff can add/edit/delete AC
  units and materials. **Administrators are view-only** on Inventory — no
  Add/Delete buttons, and the edit dialog opens read-only. Admins instead
  get a dedicated **Reports** screen (Administrator-only) with stock totals.
- **Search + filters on Inventory**: AC Units filter by Type/Status/Arrival
  date range; Materials filter by Unit/Type/AC Type. Both have a text search.
- **Arrival timestamps**: every new AC unit or material is stamped with
  the date/time it was added (`date_arrived`), shown as a table column.
- **No standalone Edit button** on Inventory or User Management —
  double-click a row to edit (or view, if you're an Administrator on
  Inventory). Delete still has its own button.
- **User status**: each user now has Active / Inactive / Resigned. Anyone
  not Active is blocked from logging in with a clear message.
- **History is now a submenu**: click "History" in the sidebar to expand
  Login History and Activity Log (who added/edited/deleted what, and when).
  Admin-only, like before.
- Table backgrounds are light blue with centered text, login screen and
  main window both open maximized, sidebar shows your logo and highlights
  the active section.

## Latest revision — New look

- **Login screen redesigned** as a two-panel card: sign-in form on the dark
  left side, company info (intro, services, customer review) on the light
  blue right side. **The right-side text is placeholder wording** - edit the
  constants at the top of `LoginFrame.java` (`COMPANY_INTRO`, `SERVICES`,
  `REVIEW_TEXT`, `REVIEW_AUTHOR`) to use your own.
- **"Forgot Password"** shows a message telling the user to ask an
  Administrator, who can set a new password in User Management (there is no
  email-based reset).
- **Light blue main area** on every screen, so the dark sidebar clearly
  reads as a separate menu. Controls and dialogs now use FlatLaf's light
  theme to match; to go back to dark controls, change `FlatLightLaf` to
  `FlatDarkLaf` in `Main.java` (the page backgrounds would then need
  revisiting).
- **Sidebar fixes:** the brand name is no longer cut off ("KhierKian AC
  Services" now wraps onto two lines), and the little arrows next to your role
  and "History" are drawn shapes instead of font characters, so they no
  longer show up as empty boxes on some PCs.

## Latest revision — Scan to auto-add AC units

- **Scanning a code that isn't in Inventory yet no longer dead-ends.** The
  phone now shows the new code with an **"+ Add as New AC Unit"** button.
  One tap creates the unit instantly: Serial No. = the scanned code,
  Quantity = 1, Status = Available. A second button, **"Not an AC unit -
  Scan Again"**, backs out if you scanned the wrong thing.
- **Why some fields are placeholders:** a barcode only contains a serial
  number, not the brand/model/type, so auto-added units show Brand
  "Unregistered" and Type "Unspecified". Finish them later on the desktop:
  Inventory -> double-click the row -> fill in the real details. To find
  them all at once, set the Type filter to "Unspecified" or search
  "Unregistered".
- Every auto-add is recorded in the Activity Log as SCAN_REGISTER.
- Auto-add currently applies to AC units only (materials still need to be
  created on the desktop so you can pick their unit/type).

## Latest revision — 5 fixes

1. **Timezone bug fixed** — `db.properties` had `serverTimezone=UTC`, which
   told the JDBC driver "the database clock is UTC" when it's actually
   already Philippine time. That mismatch was shifting every displayed
   timestamp by extra hours. Changed to `serverTimezone=Asia/Manila`.
   **You need to make this same edit in your own `db.properties`** — copying
   the whole file over yours would wipe out your real password, so just
   change `serverTimezone=UTC` to `serverTimezone=Asia/Manila` in the
   `db.url` line of your existing file.
2. **"Arrived" column no longer gets cut off** — Inventory and Report tables
   now give date/time columns enough width to show the full value.
3. **Report screen has a Period dropdown** — All Time / Today / This Week /
   This Month / This Year. Changing it re-filters all four tabs (AC Units,
   Materials, Login History, Activity Log) by their date, and the Word
   export automatically matches whatever period is currently selected.
4. **Double-click an Activity Log row** to see the full entry (staff,
   action, date, time, and the complete details text) in a popup —
   useful when "Details" is too long to read in the table.
5. **Scanner reliability** — scan/login/adjust requests now retry
   automatically a couple of times before giving up, and if it still can't
   reach the server, there's a "Tap to retry" link instead of just an error
   with no way forward.

## Latest revision — Phone Scanner

- **Runs over HTTPS**, not HTTP — phone browsers block camera access
  entirely on plain HTTP (except for "localhost"), so the scanner needs a
  real TLS connection even though it's purely local. A self-signed
  certificate (`scanner-keystore.jks`) is already generated and bundled in
  `src/main/resources/` — nothing to set up.
- **The first time your phone connects, it'll show a "connection isn't
  private" warning.** This is expected — the certificate is self-signed,
  not from a public authority, so no browser will trust it automatically.
  Tap **Advanced → Proceed** (Chrome) or **Show Details → visit this
  website** (Safari) once, and the camera will work normally after that.

- **New "Scanner" screen** (Technical Staff only, matching who can already
  edit Inventory): start a small local web server, then open the shown link
  on your phone's browser — or just scan the QR code with your phone's
  camera app — to load a scan page styled like the rest of the app.
- **Phone and computer must be on the same WiFi network.** Nothing is
  exposed to the internet; the server only listens on your local network.
- **AC units scan against their existing Serial No.** — no new field needed.
  Use the "Generate" button in the AC Unit dialog if a unit doesn't have one yet.
- **Materials get a new Barcode field** (with its own "Generate" button,
  same idea as the AC serial number) — set one for each material you want
  to be scannable.
- Scanning a code shows the item and two buttons, **+1 Received** / **−1
  Used**, so stock updates instantly — no typing. Every scan is logged to
  the Activity Log like any other inventory change.
- The phone page requires logging in with a Technical Staff account (same
  accounts as the desktop app) — Administrators can't scan, matching the
  existing view-only rule for Inventory.
- One-time setup: run `sql/migrate_v4.sql` (adds the `barcode` column to
  `materials`), and let Maven fetch the new `zxing` (QR code) dependency —
  needs internet the first time, same as previous dependency additions.
- The mobile scan page loads a small barcode-scanning library from a CDN,
  so **your phone needs internet access** (its own mobile data, or if your
  WiFi router also provides internet) the first time it opens the page.

## Latest revision

- **Report screen now covers everything**: AC Units, Materials, Login
  History, and Activity Log are all viewable as tabs in one place
  (Administrator-only), and **Export Full Report to Word** produces one
  `.docx` with a real table per section, marked "Final" so Word opens it
  read-only by default (not password-locked — someone can click "Edit
  Anyway" — but it won't be editable by accident).
- **Times are 12-hour with AM/PM**, dates stay numeric (`08/26/2026`,
  `02:30 PM`) — all still pinned to GMT+8 regardless of the machine's
  timezone.
- **Editable profile popup**: click your name in the sidebar to edit your
  own first/last name and phone number (role is shown but not editable
  there — only an Administrator can change someone's role, from User
  Management). The "@username" line was removed.
- **User Management** now has a Phone Number field alongside the existing
  Name/Username/Role/Status fields.
- **Dashboard**: the Total AC Units number is centered and much larger.
- **Login screen**: username, password, and the button are the same width
  and centered as one aligned block.

## 1. Prerequisites

- **JDK 17+** — [Adoptium](https://adoptium.net/) is a good source if you
  don't have one.
- **Maven** — VS Code's Java extension can also manage this for you.
- **MySQL** (or MariaDB) server running locally, or reachable over network.
- **VS Code** with the **Extension Pack for Java** (`vscjava.vscode-java-pack`).
  That single extension gives you the Maven view, run/debug, and the
  built-in terminal you'll use below.

## 2. Open the project

1. `File → Open Folder…` → select this `acservices` folder.
2. VS Code will detect the `pom.xml` and start resolving dependencies
   (MySQL driver, FlatLaf, jBCrypt) — this needs internet the first time.

## Database setup

**Fresh install:** `mysql -u root -p < sql/schema.sql`

**Already have the database from before?** Don't re-run schema.sql — use
the migration script instead, it only adds what's new without touching
your existing users/inventory:
```
mysql -u root -p khierkian_acs < sql/migrate_v2.sql
```
(or paste its contents into phpMyAdmin's SQL tab)

## 4. Create your first admin account

Passwords are BCrypt-hashed, so you need a real hash to insert manually
the first time (after that, User Management handles it for you):

```
mvn compile exec:java -Dexec.mainClass=com.khierkian.db.PasswordUtil -Dexec.args="yourpassword"
```

This prints a hash. Paste it into an INSERT:

```sql
INSERT INTO users (last_name, first_name, username, password, role)
VALUES ('Your', 'Name', 'admin', '<paste hash here>', 'Administrator');
```

## 5. Run it

From VS Code: open `Main.java` and click **Run** above `main()` — or press
**F5** (uses the included `.vscode/launch.json`).

From the terminal:
```
mvn compile exec:java
```

To build a single double-clickable jar:
```
mvn clean package
java -jar target/acservices.jar
```

## Project layout

```
src/main/java/com/khierkian/
  Main.java                  entry point
  db/DBConnection.java        loads db.properties, opens connections
  db/PasswordUtil.java        BCrypt hashing + legacy-plaintext migration
  session/Session.java        who's currently logged in
  model/                      plain data classes (User, AirConditioningUnit, Material, LoginRecord)
  dao/                        all SQL — UserDAO, InventoryDAO, DashboardDAO, LoginHistoryDAO
  ui/
    LoginFrame.java            standalone login window
    MainFrame.java              sidebar + CardLayout host (the fix for the flicker/glitch issue)
    DashboardPanel.java
    InventoryPanel.java         tabs: AC Units, Materials
    UserManagementPanel.java
    LoginHistoryPanel.java
    components/Theme.java       shared colors/fonts
    components/StatCard.java    reusable dashboard card widget
sql/schema.sql                 table definitions
```

## What I'd extend next, in order

1. **Connection pooling (HikariCP).** Right now every DAO call opens a
   fresh `Connection`, same as the original app — fine for a few users,
   wasteful under real load. Swap `DBConnection.getConnection()` for a
   pooled `DataSource` and nothing else in the DAOs needs to change.
2. **Externalize `db.properties` credentials** out of the jar for
   production — an environment variable or a file outside the build
   directory, so real passwords never end up committed or bundled.
3. **Unit tests for the DAOs** against an in-memory or test MySQL/H2
   instance — the admin-protection delete rule and the search logic are
   exactly the kind of thing that quietly breaks during refactors without
   a test catching it.
4. **Input validation beyond "not empty"** — e.g. reject negative
   quantities at the form level (the spinner already blocks it, but the
   DAO itself trusts its caller), and username format rules.
5. **A settings/profile screen** so a logged-in user can change their own
   password instead of relying on User Management.
6. **Table sorting/pagination** — `JTable` supports a `TableRowSorter`
   for basically free; useful once inventory grows past a screenful.
