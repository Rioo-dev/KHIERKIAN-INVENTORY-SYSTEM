-- Run this ONCE if your database already exists from before this update.
-- It only adds the new phone column — everything else is untouched.
-- In phpMyAdmin: select khierkian_acs → SQL tab → paste this whole file → Go.

USE khierkian_acs;

ALTER TABLE users
    ADD COLUMN phone VARCHAR(30) NULL;
