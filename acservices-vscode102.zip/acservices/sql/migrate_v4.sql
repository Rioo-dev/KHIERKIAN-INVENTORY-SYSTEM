-- Run this ONCE if your database already exists from before this update.
-- Adds a barcode column to materials (AC units already scan against their
-- existing Serial No. field, so no change needed there).
-- In phpMyAdmin: select khierkian_acs → SQL tab → paste this whole file → Go.

USE khierkian_acs;

ALTER TABLE materials
    ADD COLUMN barcode VARCHAR(100) NULL UNIQUE;
