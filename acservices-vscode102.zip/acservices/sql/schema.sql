-- KhierKian Air-Conditioning Services — schema
-- Matches the columns actually referenced in the app.
-- Adjust types/lengths to taste; this just gets you running.

CREATE DATABASE IF NOT EXISTS khierkian_acs;
USE khierkian_acs;

CREATE TABLE IF NOT EXISTS users (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    last_name  VARCHAR(100) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    username   VARCHAR(100) NOT NULL UNIQUE,
    password   VARCHAR(255) NOT NULL,  -- stores a BCrypt hash going forward
    role       VARCHAR(50)  NOT NULL,  -- 'Administrator' or 'Technical Staff'
    status     VARCHAR(20)  NOT NULL DEFAULT 'Active',  -- 'Active' / 'Inactive' / 'Resigned'
    phone      VARCHAR(30)  NULL
);

CREATE TABLE IF NOT EXISTS login_history (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    username    VARCHAR(100),
    last_name   VARCHAR(100),
    first_name  VARCHAR(100),
    role        VARCHAR(50),
    login_time  DATETIME NOT NULL,
    status      VARCHAR(20) NOT NULL,  -- 'SUCCESS' or 'FAILED'
    ip_address  VARCHAR(45)
);

CREATE TABLE IF NOT EXISTS air_conditioning (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    brand          VARCHAR(100) NOT NULL,
    model_no       VARCHAR(100) NOT NULL,
    specifications VARCHAR(255),
    type           VARCHAR(50),   -- Inverter / Non-Inverter / Split Type / Window Type / Portable
    quantity       INT NOT NULL DEFAULT 0,
    status         VARCHAR(30),   -- Available / Low Stock / Out of Stock
    date_sold      DATE NULL,
    date_arrived   DATETIME NULL, -- stamped automatically when a unit is added
    serial_no      VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS materials (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(150) NOT NULL,
    unit_of_measure VARCHAR(50),
    quantity        INT NOT NULL DEFAULT 0,
    type            VARCHAR(100),
    ac_type         VARCHAR(100),
    barcode         VARCHAR(100) NULL UNIQUE,
    date_arrived    DATETIME NULL  -- stamped automatically when a material is added
);

-- Records every add/edit/delete a staff member makes, and every login.
-- Powers the History > Activity Log screen.
CREATE TABLE IF NOT EXISTS activity_log (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    username    VARCHAR(100) NOT NULL,
    action      VARCHAR(50)  NOT NULL,   -- e.g. 'ADD', 'UPDATE', 'DELETE'
    description VARCHAR(255) NOT NULL,   -- e.g. 'Added AC unit: Daikin FTKC50'
    action_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- To seed your first admin account, run the app's hash generator utility
-- (see README "First-time setup") to get a real BCrypt hash for your chosen
-- password, then:
--
-- INSERT INTO users (last_name, first_name, username, password, role, status)
-- VALUES ('Your', 'Name', 'admin', '<paste generated hash here>', 'Administrator', 'Active');
