-- Run this ONCE if you already created khierkian_acs from the old schema.sql.
-- It only adds what's new — your existing users/inventory/materials rows are untouched.
-- In phpMyAdmin: select khierkian_acs → SQL tab → paste this whole file → Go.

USE khierkian_acs;

ALTER TABLE users
    ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'Active';

ALTER TABLE air_conditioning
    ADD COLUMN date_arrived DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE materials
    ADD COLUMN date_arrived DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;

CREATE TABLE IF NOT EXISTS activity_log (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    username    VARCHAR(100) NOT NULL,
    action      VARCHAR(50)  NOT NULL,
    description VARCHAR(255) NOT NULL,
    action_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
